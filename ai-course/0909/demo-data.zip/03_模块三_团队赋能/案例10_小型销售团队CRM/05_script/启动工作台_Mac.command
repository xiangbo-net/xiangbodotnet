#!/bin/bash
# 案例10 小型销售团队CRM —— macOS 一键启动
# 双击本文件即可启动团队工作台（首次双击如被拦截，请在 系统设置→隐私与安全性 中允许运行）
cd "$(dirname "$0")"
echo "正在启动 案例10 小型销售团队CRM 工作台..."
python3 serve_workbench.py
