@echo off
rem 案例10 小型销售团队CRM —— Windows 一键启动
rem 双击本文件即可启动团队工作台
cd /d "%~dp0"
echo 正在启动 案例10 小型销售团队CRM 工作台...
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 serve_workbench.py
) else (
  python serve_workbench.py
)
pause
