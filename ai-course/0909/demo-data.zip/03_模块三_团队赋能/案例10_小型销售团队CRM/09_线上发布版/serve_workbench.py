#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
案例10 小型销售团队CRM - 线上发布版服务
仅依赖 Python 3 标准库，无需安装任何第三方包。

部署环境要求：
  - 监听 PORT 环境变量指定的端口，绑定 0.0.0.0
  - 数据目录与前端页面位于本脚本同级：
      04_archive/*.csv   五张数据表（团队员工表/团队客户表/客户跟进记录表/团队任务表/销售业绩表）
      06_webapp/index.html  前端单文件

注意（与本地版的差异）：
  - 本版本不自动打开浏览器、不做局域网地址探测
  - 线上写入的数据保存在云端沙箱的 CSV 中，不回写本地文件
  - 密码明文存储仅供教学演示，公开链接场景请注意数据安全
"""
import csv
import json
import os
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(ROOT, "04_archive")
WEB_DIR = os.path.join(ROOT, "06_webapp")

CSV_FILES = {
    "customers": "团队客户表.csv",
    "records": "客户跟进记录表.csv",
    "tasks": "团队任务表.csv",
    "performance": "销售业绩表.csv",
    "employees": "团队员工表.csv",
}

# 内存会话表：token -> {员工信息}
SESSIONS = {}
SESSION_TTL = 12 * 3600  # 会话有效期 12 小时

# 写文件锁，避免多人同时保存互相覆盖
FILE_LOCK = threading.Lock()


# ---------- CSV 读写 ----------

def csv_path(key):
    return os.path.join(DATA_DIR, CSV_FILES[key])


def read_csv(key):
    path = csv_path(key)
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8-sig", newline="") as f:
        return [dict(r) for r in csv.DictReader(f)]


def write_csv(key, rows, header=None):
    if rows:
        header = list(rows[0].keys())
    if not header:
        return
    path = csv_path(key)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=header)
        w.writeheader()
        w.writerows(rows)
    os.replace(tmp, path)


def next_id(rows, field, prefix, width=3):
    mx = 0
    for r in rows:
        v = (r.get(field) or "").strip()
        if v.startswith(prefix) and v[len(prefix):].isdigit():
            mx = max(mx, int(v[len(prefix):]))
    return "%s%0*d" % (prefix, width, mx + 1)


# ---------- 鉴权 ----------

def find_user(username, password):
    for e in read_csv("employees"):
        if (e.get("登录用户名") or "").strip() == username.strip():
            if (e.get("密码") or "") == password:
                return e
            return None  # 用户名存在但密码不对
    return None


def get_session(token):
    s = SESSIONS.get(token)
    if not s:
        return None
    if time.time() - s["loginAt"] > SESSION_TTL:
        SESSIONS.pop(token, None)
        return None
    return s


# ---------- HTTP Handler ----------

class Handler(BaseHTTPRequestHandler):
    server_version = "TeamCRM/1.0"

    def log_message(self, fmt, *args):
        pass  # 静默访问日志

    # ---- 工具 ----
    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        data = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _read_body(self):
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            return {}
        return json.loads(self.rfile.read(length).decode("utf-8"))

    def _auth(self):
        token = self.headers.get("X-Auth-Token", "")
        return get_session(token)

    # ---- GET ----
    def do_GET(self):
        if self.path in ("/", "/index.html"):
            try:
                with open(os.path.join(WEB_DIR, "index.html"), "rb") as f:
                    self._send(200, f.read(), "text/html; charset=utf-8")
            except FileNotFoundError:
                self._send(404, {"error": "06_webapp/index.html 未找到"})
        elif self.path == "/api/data":
            if not self._auth():
                self._send(401, {"error": "未登录或会话已过期"})
                return
            employees = []
            for e in read_csv("employees"):
                employees.append({k: v for k, v in e.items() if k != "密码"})
            data = {k: read_csv(k) for k in ("customers", "records", "tasks", "performance")}
            data["employees"] = employees
            data["me"] = self._auth()["user"]
            self._send(200, data)
        else:
            self._send(404, {"error": "not found"})

    # ---- POST ----
    def do_POST(self):
        try:
            payload = self._read_body()
        except Exception:
            self._send(400, {"error": "请求体格式错误"})
            return

        if self.path == "/api/login":
            self._login(payload)
            return

        if self.path == "/api/logout":
            SESSIONS.pop(self.headers.get("X-Auth-Token", ""), None)
            self._send(200, {"ok": True})
            return

        session = self._auth()
        if not session:
            self._send(401, {"error": "未登录或会话已过期"})
            return
        user = session["user"]

        if self.path == "/api/records":
            self._records(payload, user)
        elif self.path == "/api/tasks":
            self._tasks(payload, user)
        elif self.path == "/api/customers":
            self._customers(payload, user)
        else:
            self._send(404, {"error": "not found"})

    # ---- 业务：登录 ----
    def _login(self, payload):
        username = (payload.get("username") or "").strip()
        password = payload.get("password") or ""
        if not username or not password:
            self._send(400, {"error": "请输入用户名和密码"})
            return
        user = find_user(username, password)
        if not user:
            self._send(401, {"error": "用户名或密码错误（演示账号见员工表）"})
            return
        token = uuid.uuid4().hex
        SESSIONS[token] = {
            "loginAt": time.time(),
            "user": {
                "员工ID": user.get("员工ID", ""),
                "姓名": user.get("姓名", ""),
                "部门": user.get("部门", ""),
                "角色": user.get("角色", ""),
                "手机": user.get("手机", ""),
            },
        }
        self._send(200, {"ok": True, "token": token, "user": SESSIONS[token]["user"]})

    # ---- 业务：跟进记录 ----
    def _records(self, payload, user):
        if payload.get("action") != "add":
            self._send(400, {"error": "未知操作"})
            return
        with FILE_LOCK:
            rows = read_csv("records")
            rec = {
                "跟进ID": next_id(rows, "跟进ID", "F"),
                "客户编号": (payload.get("客户编号") or "").strip(),
                "客户名称": (payload.get("客户名称") or "").strip(),
                "日期": (payload.get("日期") or "").strip() or time.strftime("%Y-%m-%d"),
                "沟通方式": (payload.get("沟通方式") or "").strip(),
                "跟进人": user.get("姓名", ""),
                "沟通摘要": (payload.get("沟通摘要") or "").strip(),
                "客户反馈": (payload.get("客户反馈") or "").strip(),
                "下一步动作": (payload.get("下一步动作") or "").strip(),
            }
            if not rec["客户名称"] or not rec["沟通摘要"]:
                self._send(400, {"error": "客户名称与沟通摘要不能为空"})
                return
            # 同步客户表：刷新下一步动作与下次跟进日期
            customers = read_csv("customers")
            for c in customers:
                if c.get("客户编号") == rec["客户编号"] or c.get("客户名称") == rec["客户名称"]:
                    c["下次跟进日期"] = payload.get("下次跟进日期") or c.get("下次跟进日期", "")
                    if rec["下一步动作"]:
                        c["下一步动作"] = rec["下一步动作"]
                    break
            rows.append(rec)
            write_csv("records", rows)
            if customers:
                write_csv("customers", customers)
        self._send(200, {"ok": True, "record": rec})

    # ---- 业务：任务 ----
    def _tasks(self, payload, user):
        action = payload.get("action")
        with FILE_LOCK:
            rows = read_csv("tasks")
            if action == "add":
                task = {
                    "任务ID": next_id(rows, "任务ID", "T"),
                    "客户名称": (payload.get("客户名称") or "").strip(),
                    "任务内容": (payload.get("任务内容") or "").strip(),
                    "负责人": (payload.get("负责人") or user.get("姓名", "")).strip(),
                    "截止日期": (payload.get("截止日期") or "").strip(),
                    "状态": payload.get("状态") or "待办",
                    "创建日期": time.strftime("%Y-%m-%d"),
                    "备注": (payload.get("备注") or "").strip(),
                }
                if not task["客户名称"] or not task["任务内容"]:
                    self._send(400, {"error": "客户名称与任务内容不能为空"})
                    return
                rows.append(task)
                write_csv("tasks", rows)
                self._send(200, {"ok": True, "task": task})
            elif action == "update":
                tid = payload.get("任务ID")
                for r in rows:
                    if r.get("任务ID") == tid:
                        for k in ("状态", "任务内容", "负责人", "截止日期", "备注"):
                            if payload.get(k) is not None:
                                r[k] = str(payload[k])
                        write_csv("tasks", rows)
                        self._send(200, {"ok": True})
                        return
                self._send(404, {"error": "任务不存在"})
            elif action == "delete":
                tid = payload.get("任务ID")
                new_rows = [r for r in rows if r.get("任务ID") != tid]
                if len(new_rows) == len(rows):
                    self._send(404, {"error": "任务不存在"})
                    return
                write_csv("tasks", new_rows)
                self._send(200, {"ok": True})
            else:
                self._send(400, {"error": "未知操作"})

    # ---- 业务：新增客户 ----
    def _customers(self, payload, user):
        if payload.get("action") != "add":
            self._send(400, {"error": "未知操作"})
            return
        with FILE_LOCK:
            rows = read_csv("customers")
            cust = {
                "客户编号": next_id(rows, "客户编号", "C"),
                "客户名称": (payload.get("客户名称") or "").strip(),
                "行业": (payload.get("行业") or "").strip(),
                "地区": (payload.get("地区") or "").strip(),
                "客户等级": payload.get("客户等级") or "C",
                "当前阶段": payload.get("当前阶段") or "初步接触",
                "负责人": (payload.get("负责人") or user.get("姓名", "")).strip(),
                "联系人": (payload.get("联系人") or "").strip(),
                "联系电话": (payload.get("联系电话") or "").strip(),
                "预计商机金额": (payload.get("预计商机金额") or "0").strip(),
                "成交概率": payload.get("成交概率") or "10%",
                "下次跟进日期": (payload.get("下次跟进日期") or "").strip(),
                "下一步动作": (payload.get("下一步动作") or "").strip(),
                "创建日期": time.strftime("%Y-%m-%d"),
            }
            if not cust["客户名称"]:
                self._send(400, {"error": "客户名称不能为空"})
                return
            rows.append(cust)
            write_csv("customers", rows)
        self._send(200, {"ok": True, "customer": cust})


# ---------- 启动 ----------

def main():
    port = int(os.environ.get("PORT", "8800"))
    server = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    print("TeamCRM server listening on 0.0.0.0:%d" % port, flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n已退出。")


if __name__ == "__main__":
    main()
