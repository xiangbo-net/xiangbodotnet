@echo off
rem 案例6 销售跟进工作台 - Windows 快速启动
chcp 65001 >nul
cd /d "%~dp0"
where python >nul 2>nul
if %errorlevel% neq 0 (
  echo [ERROR] Python not found. Please install Python 3 from https://www.python.org/
  pause
  exit /b 1
)
python "05_script\serve_workbench.py"
pause
