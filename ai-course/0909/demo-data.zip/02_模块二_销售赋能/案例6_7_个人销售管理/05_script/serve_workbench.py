#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
案例6 销售跟进工作台 - 本地托管服务
仅依赖 Python 3 标准库。启动后自动打开浏览器访问 http://127.0.0.1:8765

数据来源（相对案例根目录）：
  04_archive/01_客户跟进表/*.csv   客户跟进台账
  04_archive/02_线索库/线索库.csv   线索库
前端：
  06_webapp/index.html
"""
import csv
import json
import os
import sys
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TABLE_DIR = os.path.join(ROOT, "04_archive", "01_客户跟进表")
LEAD_CSV = os.path.join(ROOT, "04_archive", "02_线索库", "线索库.csv")
WEB_DIR = os.path.join(ROOT, "06_webapp")
TASK_CSV = os.path.join(TABLE_DIR, "跟进任务表.csv")

TABLE_FILES = {
    "customers": "客户跟进总表.csv",
    "records": "跟进记录明细.csv",
    "funnel": "商机漏斗表.csv",
    "deals": "成交业绩表.csv",
    "tasks": "跟进任务表.csv",
}


def read_csv(path):
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8-sig", newline="") as f:
        return [dict(r) for r in csv.DictReader(f)]


def write_tasks(rows):
    if not rows:
        header = ["任务ID", "客户名称", "任务内容", "负责人", "截止日期", "状态", "创建日期", "备注"]
    else:
        header = list(rows[0].keys())
    tmp = TASK_CSV + ".tmp"
    with open(tmp, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=header)
        w.writeheader()
        w.writerows(rows)
    os.replace(tmp, TASK_CSV)


def next_task_id(rows):
    mx = 0
    for r in rows:
        tid = (r.get("任务ID") or "").strip()
        if tid.startswith("T") and tid[1:].isdigit():
            mx = max(mx, int(tid[1:]))
    return "T%03d" % (mx + 1)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        data = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path in ("/", "/index.html"):
            try:
                with open(os.path.join(WEB_DIR, "index.html"), "rb") as f:
                    self._send(200, f.read(), "text/html; charset=utf-8")
            except FileNotFoundError:
                self._send(404, {"error": "index.html 未找到"})
        elif self.path == "/api/data":
            data = {k: read_csv(os.path.join(TABLE_DIR, v)) for k, v in TABLE_FILES.items()}
            data["leads"] = read_csv(LEAD_CSV)
            data["serverRoot"] = ROOT
            self._send(200, data)
        else:
            self._send(404, {"error": "not found"})

    def do_POST(self):
        if self.path != "/api/tasks":
            self._send(404, {"error": "not found"})
            return
        try:
            length = int(self.headers.get("Content-Length") or 0)
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
        except Exception:
            self._send(400, {"error": "请求体格式错误"})
            return
        action = payload.get("action")
        rows = read_csv(TASK_CSV)
        if action == "add":
            task = {
                "任务ID": next_task_id(rows),
                "客户名称": (payload.get("客户名称") or "").strip(),
                "任务内容": (payload.get("任务内容") or "").strip(),
                "负责人": (payload.get("负责人") or "").strip(),
                "截止日期": (payload.get("截止日期") or "").strip(),
                "状态": payload.get("状态") or "待办",
                "创建日期": payload.get("创建日期") or "",
                "备注": payload.get("备注") or "",
            }
            if not task["任务内容"] or not task["客户名称"]:
                self._send(400, {"error": "客户名称与任务内容不能为空"})
                return
            rows.append(task)
            write_tasks(rows)
            self._send(200, {"ok": True, "task": task})
        elif action == "update":
            tid = payload.get("任务ID")
            for r in rows:
                if r.get("任务ID") == tid:
                    for k in ("状态", "任务内容", "负责人", "截止日期", "备注"):
                        if k in payload and payload[k] is not None:
                            r[k] = str(payload[k])
                    break
            else:
                self._send(404, {"error": "任务不存在"})
                return
            write_tasks(rows)
            self._send(200, {"ok": True})
        elif action == "delete":
            tid = payload.get("任务ID")
            new_rows = [r for r in rows if r.get("任务ID") != tid]
            if len(new_rows) == len(rows):
                self._send(404, {"error": "任务不存在"})
                return
            write_tasks(new_rows)
            self._send(200, {"ok": True})
        else:
            self._send(400, {"error": "未知操作"})


def main():
    port = 8765
    while True:
        try:
            server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
            break
        except OSError:
            port += 1
            if port > 8790:
                print("未找到可用端口（8765-8790），请检查端口占用。")
                sys.exit(1)
    url = "http://127.0.0.1:%d" % port
    print("=" * 46)
    print(" 案例6 销售跟进工作台已启动")
    print(" 访问地址: %s" % url)
    print(" 数据目录: %s" % TABLE_DIR)
    print(" 按 Ctrl+C 退出")
    print("=" * 46)
    threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n已退出。")


if __name__ == "__main__":
    main()
