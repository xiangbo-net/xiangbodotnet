#!/bin/bash
# 案例6 销售跟进工作台 - macOS 快速启动
cd "$(dirname "$0")"
if ! command -v python3 >/dev/null 2>&1; then
  echo "[错误] 未找到 python3，请先安装 Python 3（https://www.python.org/downloads/）"
  read -r -p "按回车键退出..." _
  exit 1
fi
python3 "05_script/serve_workbench.py"
