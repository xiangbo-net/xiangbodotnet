#!/usr/bin/env bash
# ============================================================
# 案例5 留资页面 启动脚本（macOS / Linux）
# 用法：
#   bash run_macos_linux.sh            # 默认端口 8000
#   bash run_macos_linux.sh 9000       # 指定端口
# 说明：
#   - 自动使用 python3（仅标准库，无第三方依赖）
#   - 启动后自动用系统浏览器打开 http://127.0.0.1:<port>
#   - 停止：在终端按 Ctrl+C
# ============================================================
set -e
cd "$(dirname "$0")"

PORT="${1:-8000}"
URL="http://127.0.0.1:${PORT}"

echo "==> 案例5 留资页面服务启动中..."
echo "==> 页面地址: ${URL}   (停止请按 Ctrl+C)"

# 后台稍等 1 秒后尝试自动打开浏览器（macOS 用 open）
if command -v open >/dev/null 2>&1; then
  ( sleep 1; open "${URL}" >/dev/null 2>&1 || true ) &
elif command -v xdg-open >/dev/null 2>&1; then
  ( sleep 1; xdg-open "${URL}" >/dev/null 2>&1 || true ) &
fi

exec python3 server.py "${PORT}"
