#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
案例5｜资料包打包脚本
把 04_archive/资料包/ 下的源稿 *.md 打包为：
    04_archive/资料包/启辰自动化_工业自动化改造方案资料包.zip
页面提交留资后下载的即该 zip。修改源稿后重新运行本脚本即可更新。

仅使用 Python 3 标准库。运行：python3 build_package.py
"""

import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC_DIR = ROOT / "04_archive" / "资料包"
ZIP_FILE = SRC_DIR / "启辰自动化_工业自动化改造方案资料包.zip"


def main():
    files = sorted(SRC_DIR.glob("*.md"))
    if not files:
        sys.exit("未找到资料包源稿（%s 下无 *.md）" % SRC_DIR)
    with zipfile.ZipFile(ZIP_FILE, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in files:
            zf.write(f, arcname=f.name)
            print("已加入:", f.name)
    print("已生成:", ZIP_FILE)
    print("文件数 :", len(files), "| 大小:", round(ZIP_FILE.stat().st_size / 1024, 1), "KB")


if __name__ == "__main__":
    main()
