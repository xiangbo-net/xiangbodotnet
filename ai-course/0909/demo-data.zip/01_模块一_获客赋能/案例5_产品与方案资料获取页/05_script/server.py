#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
案例5｜产品与方案资料获取页 · 本地前后端服务（后端）

职责：
1. 托管 06_webapp/ 下的静态页面（index.html / styles.css / app.js）；
2. 接收留资提交  POST /api/submit      → 追加写入 04_archive/收集表单.csv；
3. 校验后提供下载 GET  /api/package?submission_id=FORM-xxxx → 04_archive/资料包/ 下的 zip。

技术说明：
- 仅使用 Python 3 标准库，无第三方依赖；
- 运行方式（详见 05_script/README.md）：
    python3 server.py [port]     # 默认 8000
- 建议通过 run_macos_linux.sh / run_windows.bat 一键启动并自动打开浏览器。
"""

import csv
import json
import re
import sys
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, urlparse

ROOT = Path(__file__).resolve().parents[1]
WEBROOT = ROOT / "06_webapp"
CSV_FILE = ROOT / "04_archive" / "收集表单.csv"
PACKAGE_DIR = ROOT / "04_archive" / "资料包"
PACKAGE_FILE = PACKAGE_DIR / "启辰自动化_工业自动化改造方案资料包.zip"

FIELDS = ["提交ID", "姓名", "企业", "职务", "联系方式", "需求方向",
          "隐私同意", "来源内容ID", "UTM", "提交时间"]
DEFAULT_SOURCE_ID = "LANDING-005-001"
DEFAULT_UTM = "course_demo"
NEED_OPTIONS = ["产线自动化评估", "机器视觉", "机器人上下料", "设备数据采集", "其他（暂不确定）"]

EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")
_write_lock = __import__("threading").Lock()

MIME = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".svg": "image/svg+xml",
    ".ico": "image/x-icon",
    ".zip": "application/zip",
}


# ---------------------------------------------------------------- 数据层
def ensure_header():
    """文件不存在或为空时，写入带 BOM 的表头（Excel 直接可开）。"""
    if CSV_FILE.exists() and CSV_FILE.stat().st_size > 0:
        return
    CSV_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(CSV_FILE, "w", newline="", encoding="utf-8-sig") as f:
        csv.writer(f).writerow(FIELDS)


def read_rows():
    if not CSV_FILE.exists() or CSV_FILE.stat().st_size == 0:
        return []
    with open(CSV_FILE, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def append_row(row):
    """追加一行（不覆盖既有行）。表头用 utf-8-sig 写 BOM，数据行用 utf-8 追加。"""
    with _write_lock:
        ensure_header()
        with open(CSV_FILE, "a", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=FIELDS)
            writer.writerow(row)


def next_submission_id():
    existing = read_rows()
    return f"FORM-{len(existing) + 1:04d}"


def submission_exists(sid):
    return any(r.get("提交ID", "").strip() == sid and r.get("隐私同意", "").strip() == "是"
               for r in read_rows())


def sanitize(value, max_len=80):
    """防 CSV 注入 + 去控制字符：Excel 打开时以 =+-@ 开头会被当公式。"""
    if value is None:
        return ""
    s = "".join(ch for ch in str(value) if ch not in "\r\n\t")[:max_len].strip()
    if s and s[0] in "=+-@":
        s = "'" + s
    return s


# ---------------------------------------------------------------- 校验
def validate_payload(p):
    errs = []
    name = sanitize(p.get("name"), 30)
    company = sanitize(p.get("company"), 60)
    role = sanitize(p.get("role"), 30)
    contact = sanitize(p.get("contact"), 80)
    need = sanitize(p.get("need"), 30)
    privacy = p.get("privacy", "")

    if not name:
        errs.append("姓名不能为空")
    if not company:
        errs.append("企业不能为空")
    if not role:
        errs.append("职务不能为空")
    if not contact:
        errs.append("联系方式不能为空")
    elif not EMAIL_RE.match(contact):
        errs.append("联系方式须为有效邮箱格式")
    if need not in NEED_OPTIONS:
        errs.append("需求方向不在允许范围内")
    if privacy != "是":
        errs.append("须勾选同意教学模拟隐私说明")

    source_id = sanitize(p.get("sourceContentId"), 40) or DEFAULT_SOURCE_ID
    utm = sanitize(p.get("utm"), 40) or DEFAULT_UTM
    if errs:
        return None, errs
    return {"name": name, "company": company, "role": role,
            "contact": contact, "need": need, "source_id": source_id, "utm": utm}, None


# ---------------------------------------------------------------- HTTP
class Handler(BaseHTTPRequestHandler):
    server_version = "Case5LeadGen/1.0"

    # ---------- 通用 ----------
    def _send_json(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _send_file(self, path: Path):
        mime = MIME.get(path.suffix.lower(), "application/octet-stream")
        with open(path, "rb") as f:
            body = f.read()
        self.send_response(200)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        sys.stdout.write("[%s] %s\n" % (datetime.now().strftime("%H:%M:%S"), fmt % args))

    # ---------- GET ----------
    def do_GET(self):
        parsed = urlparse(self.path)
        # 资料包下载：必须携带已提交的 提交ID，且该行已勾选隐私同意
        if parsed.path == "/api/package":
            sid = (parse_qs(parsed.query).get("submission_id") or [""])[0]
            if not sid or not submission_exists(sid):
                self._send_json(404, {"code": 404, "message": "提交ID不存在或未通过隐私同意校验，请先完成表单提交。"})
                return
            if not PACKAGE_FILE.exists():
                self._send_json(500, {"code": 500, "message": "资料包文件缺失，请先运行 05_script/build_package.py 生成。"})
                return
            body = PACKAGE_FILE.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "application/zip")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Content-Disposition",
                             "attachment; filename=\"Qichen-Automation-Package.zip\"; "
                             "filename*=UTF-8''" + quote(PACKAGE_FILE.name))
            self.end_headers()
            self.wfile.write(body)
            return

        # 静态页面（仅限 WEBROOT 内，防目录穿越）
        rel = parsed.path.lstrip("/")
        if not rel:
            rel = "index.html"
        target = (WEBROOT / rel).resolve()
        if WEBROOT.resolve() not in target.parents and target != WEBROOT.resolve():
            self._send_json(404, {"code": 404, "message": "Not Found"})
            return
        if not target.is_file():
            self._send_json(404, {"code": 404, "message": "文件不存在：" + rel})
            return
        self._send_file(target)

    # ---------- POST ----------
    def do_POST(self):
        parsed = urlparse(self.path)
        if parsed.path != "/api/submit":
            self._send_json(404, {"code": 404, "message": "接口不存在"})
            return
        try:
            length = int(self.headers.get("Content-Length", 0))
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
        except Exception:
            self._send_json(400, {"code": 400, "message": "请求体不是合法 JSON"})
            return

        clean, errs = validate_payload(payload)
        if errs:
            self._send_json(400, {"code": 400, "message": "；".join(errs)})
            return

        submission_id = next_submission_id()
        row = {
            "提交ID": submission_id,
            "姓名": clean["name"],
            "企业": clean["company"],
            "职务": clean["role"],
            "联系方式": clean["contact"],
            "需求方向": clean["need"],
            "隐私同意": "是",
            "来源内容ID": clean["source_id"],
            "UTM": clean["utm"],
            "提交时间": datetime.now().astimezone().isoformat(timespec="seconds"),
        }
        append_row(row)
        sys.stdout.write(f"[留资] {submission_id} | {clean['company']} | {clean['need']}\n")
        self._send_json(200, {"code": 0, "message": "ok", "submission_id": submission_id})


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    ensure_header()
    if not PACKAGE_FILE.exists():
        sys.stderr.write("[警告] 未找到资料包 zip：%s\n请先运行 python3 build_package.py 生成。\n" % PACKAGE_FILE)
    url = f"http://127.0.0.1:{port}"
    print("=" * 60)
    print(" 案例5｜方案资料获取页 · 本地服务已启动")
    print(" 页面地址 :", url)
    print(" 留资数据 :", CSV_FILE)
    print(" 停止服务 : Ctrl + C")
    print("=" * 60)
    try:
        ThreadingHTTPServer(("127.0.0.1", port), Handler).serve_forever()
    except KeyboardInterrupt:
        print("\n已停止服务。留资数据已保存至", CSV_FILE)


if __name__ == "__main__":
    main()
