@echo off
rem ============================================================
rem Case5 Lead-gen page starter (Windows)
rem Usage:
rem   run_windows.bat            default port 8000
rem   run_windows.bat 9000       custom port
rem Notes:
rem   - Uses system Python (stdlib only, no third-party deps)
rem   - Opens default browser at http://127.0.0.1:<port>
rem   - Stop: press Ctrl+C in this window
rem ============================================================
cd /d "%~dp0"

set "PORT=8000"
if not "%~1"=="" set "PORT=%~1"
set "URL=http://127.0.0.1:%PORT%"

echo ==^> Case5 page service starting...
echo ==^> URL: %URL%   (press Ctrl+C to stop)

start "" "%URL%"

python server.py "%PORT%"
if errorlevel 1 (
  echo.
  echo [ERROR] Failed to start. Make sure Python is installed and on PATH.
  echo Try: python --version
)
pause
