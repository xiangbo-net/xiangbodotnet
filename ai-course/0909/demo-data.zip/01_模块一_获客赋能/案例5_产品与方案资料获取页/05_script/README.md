# 05_script｜脚本运行说明

> 案例5「产品与方案资料获取页」的本地脚本目录。全部脚本**仅使用 Python 3 标准库**，无第三方依赖。

## 一、脚本清单

| 脚本 | 用途 | 运行方式 |
|---|---|---|
| `server.py` | **前后端服务**：托管 `06_webapp/` 静态页面；接收留资 `POST /api/submit` 写入 `04_archive/收集表单.csv`；校验后提供资料包下载 `GET /api/package` | `python3 server.py [port]` |
| `run_macos_linux.sh` | macOS / Linux 一键启动（自动打开浏览器，默认端口 8000） | `bash run_macos_linux.sh [port]` |
| `run_windows.bat` | Windows 一键启动（自动打开浏览器，默认端口 8000） | 双击或 `run_windows.bat [port]` |
| `build_package.py` | 将 `04_archive/资料包/*.md` 打包为《方案资料包.zip》（页面下载文件） | `python3 build_package.py` |

## 二、推荐运行方式（双平台）

**macOS / Linux**

```bash
bash 05_script/run_macos_linux.sh        # 案例根目录执行，或 cd 05_script 后执行
```

**Windows**

```bat
双击 05_script\run_windows.bat
```

启动后浏览器自动打开 `http://127.0.0.1:8000`，终端按 `Ctrl+C` 停止。

> 平台差异点：mac/Linux 用 `python3` + `open`，Windows 用 `python` + `start`——这正是演示步骤三要求考虑两种系统的原因。端口被占用时可传参换端口：`run_macos_linux.sh 9000` / `run_windows.bat 9000`。

## 三、接口约定（页面 app.js 与 server.py 配套）

| 接口 | 说明 | 成功返回 |
|---|---|---|
| `POST /api/submit` | Body JSON：`name / company / role / contact / need / privacy / sourceContentId / utm` | `{"code":0,"submission_id":"FORM-0001"}` |
| `GET /api/package?submission_id=FORM-xxxx` | 校验该提交存在于 CSV 且隐私同意=是后返回资料包 zip | `application/zip` 附件下载 |

**服务端校验规则**：字段非空；联系方式须为邮箱格式；`privacy` 必须为"是"；需求方向在白名单内。非法请求返回 `{"code":400,...}`。

## 四、数据写入口径

1. `server.py` 只**追加**写入 `04_archive/收集表单.csv`（UTF-8 带 BOM，Excel 可直接打开），不覆盖既有行；
2. 表单若不存在/为空表，服务启动时自动创建仅表头模板；
3. 字段做防 CSV 注入处理（首字符为 `= + - @` 时加前缀 `'`），并去除换行控制符；
4. 页面留资数据随课堂现场提交产生；测试后如需重置，将 CSV 恢复为仅表头即可。

## 五、常见问题

| 现象 | 处理 |
|---|---|
| 双击 `06_webapp/index.html` 提交无反应 | 必须通过本目录服务访问 `http://127.0.0.1:8000`（页面依赖后端接口，`file://` 无法提交） |
| `Address already in use` | 端口被占用，换端口启动（见上文） |
| 提交提示"资料包文件缺失" | 先运行 `python3 05_script/build_package.py` 生成 zip |
| Windows 中文乱码 | bat 仅含 ASCII；页面与 CSV 均为 UTF-8，用浏览器/Excel 正常打开 |
