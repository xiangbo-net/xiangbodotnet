/* ============================================================
   案例5｜产品与方案资料获取页 · 前端逻辑
   功能：表单校验 → POST /api/submit 留资 → 展示"三步下载"
   ------------------------------------------------------------
   接口约定（与 05_script/server.py 配套）：
   - POST /api/submit  body: {name,company,role,contact,need,
     privacy,sourceContentId,utm} → {code,message,submission_id}
   - GET  /api/package?submission_id=FORM-xxxx → 资料包 zip
   ============================================================ */

(() => {
  "use strict";

  const $ = (sel) => document.querySelector(sel);
  const SOURCE_CONTENT_ID = "LANDING-005-001"; // 页面标识（教学模拟）

  const form = $("#leadForm");
  const formMsg = $("#formMsg");
  const formPanel = $("#formPanel");
  const successPanel = $("#successPanel");
  const receipt = $("#receipt");
  const downloadBtn = $("#downloadBtn");
  const againBtn = $("#againBtn");
  const toast = $("#toast");

  let toastTimer = null;
  function showToast(text, isError = false) {
    toast.textContent = text;
    toast.classList.toggle("error", isError);
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2600);
  }

  /* ---------- 表单校验 ---------- */
  function validate() {
    const name = form.name.value.trim();
    const company = form.company.value.trim();
    const role = form.role.value.trim();
    const contact = form.contact.value.trim();
    const need = form.need.value;
    const privacy = form.privacy.checked;

    if (!name || !company || !role || !contact || !need) return "请完整填写姓名、企业、职务、联系方式与需求方向。";
    const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRe.test(contact)) return "联系方式请填写有效邮箱（课堂请使用虚构邮箱）。";
    if (!privacy) return '请先勾选同意“教学模拟隐私说明”。';
    return null;
  }

  /* ---------- 提交留资 ---------- */
  async function submit(data) {
    const resp = await fetch("/api/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const json = await resp.json().catch(() => ({}));
    if (!resp.ok || json.code !== 0) {
      throw new Error((json && json.message) || "服务暂时不可用，请确认已通过 05_script 启动本地服务。");
    }
    return json;
  }

  function readUtm() {
    try {
      return new URLSearchParams(window.location.search).get("utm") || "course_demo";
    } catch (e) {
      return "course_demo";
    }
  }

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const err = validate();
    if (err) {
      formMsg.textContent = err;
      formMsg.className = "form-msg err";
      showToast(err, true);
      return;
    }
    formMsg.textContent = "正在登记，请稍候…";
    formMsg.className = "form-msg";

    const payload = {
      name: form.name.value.trim(),
      company: form.company.value.trim(),
      role: form.role.value.trim(),
      contact: form.contact.value.trim(),
      need: form.need.value,
      privacy: "是",
      sourceContentId: SOURCE_CONTENT_ID,
      utm: readUtm(),
    };

    try {
      const res = await submit(payload);
      // 成功 → 切换到"三步下载"面板
      formPanel.classList.add("hidden");
      successPanel.classList.remove("hidden");

      receipt.innerHTML =
        "留资回执：<b>" + (res.submission_id || "") + "</b> · " +
        escapeHtml(form.name.value.trim()) + " · " + escapeHtml(form.company.value.trim()) +
        "<br />已写入 <b>04_archive/收集表单.csv</b>（教学模拟，未外发）。";

      const base = "/api/package?submission_id=" + encodeURIComponent(res.submission_id || "");
      downloadBtn.href = base;
      downloadBtn.setAttribute("aria-disabled", "false");
      showToast("留资成功：" + (res.submission_id || "") + "，可下载资料包");
      successPanel.scrollIntoView({ behavior: "smooth", block: "center" });
    } catch (errObj) {
      formMsg.textContent = errObj.message || "提交失败，请重试。";
      formMsg.className = "form-msg err";
      showToast(formMsg.textContent, true);
    }
  });

  /* 返回重新填写 */
  againBtn.addEventListener("click", () => {
    successPanel.classList.add("hidden");
    formPanel.classList.remove("hidden");
    formMsg.textContent = "";
    formMsg.className = "form-msg";
  });

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
    }[c]));
  }
})();
