# 05_script 运行说明

## 脚本清单

| 文件 | 用途 |
|---|---|
| `build_leadboard.py` | ① 若 `04_archive/线索库.xlsx` 不存在则创建规范模板；② 读取线索总表数据，导出 `06_webapp/leadboard-data.js` 供看板使用 |
| `requirements.txt` | 依赖声明（openpyxl） |

## 运行步骤

1. 安装依赖（仅首次）：

   ```bash
   pip install -r 05_script/requirements.txt
   ```

2. 在**案例根目录**执行：

   ```bash
   python3 05_script/build_leadboard.py
   ```

3. 成功时输出 JSON 摘要（线索数、核验数、A/B/C 分布），并生成/更新：
   - `04_archive/线索库.xlsx`（仅当不存在时创建模板）
   - `06_webapp/leadboard-data.js`（每次运行均刷新）

4. 打开看板验证：用浏览器打开 `06_webapp/线索工作看板.html`。

## 使用时机（对应七步闭环）

- **第六步（沉淀）**：写入线索库前，若 `线索库.xlsx` 不存在，先运行本脚本初始化模板，再由智能体写入数据。
- **第七步（看板）**：线索库更新后运行本脚本刷新 `leadboard-data.js`，看板即可显示最新数据。

## 异常处理

- 提示缺少 openpyxl：执行 `pip install openpyxl` 后重试。
- 提示缺少『线索总表』工作表：说明 xlsx 结构被改动，请对照《04_archive/线索库说明.md》修复或删除该文件后重新运行（重建前先备份）。
- 数据为空：脚本正常退出，看板显示空状态引导，属预期行为，禁止编造数据填充。
