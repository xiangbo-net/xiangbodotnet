#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
案例3_招标获客｜线索库初始化 + 看板数据导出脚本

功能：
  1. 若 04_archive/线索库.xlsx 不存在，按规范创建模板（线索总表 / 评分标准 / 版本记录 三个工作表）；
  2. 读取线索总表数据，统计汇总，导出 06_webapp/leadboard-data.js 供 HTML 看板使用。

用法（在案例根目录执行）：
  python3 05_script/build_leadboard.py

依赖：openpyxl >= 3.1（pip install openpyxl）
退出码：0 成功；1 失败（错误信息打印到 stderr）。
"""
import sys
import json
from pathlib import Path
from datetime import date

try:
    from openpyxl import Workbook, load_workbook
    from openpyxl.styles import Font, PatternFill, Alignment
except ImportError:
    print("错误：缺少依赖 openpyxl，请先执行：pip install openpyxl", file=sys.stderr)
    sys.exit(1)

ROOT = Path(__file__).resolve().parents[1]
XLSX_PATH = ROOT / "04_archive" / "线索库.xlsx"
DATA_JS_PATH = ROOT / "06_webapp" / "leadboard-data.js"
TODAY = date.today().isoformat()

# ---- 线索总表字段（与 04_archive/线索库说明.md 保持一致）----
HEADERS = [
    "线索ID", "项目名称", "采购主体", "区域", "预算(万元)",
    "公告日期", "报名/截止日期", "来源平台", "公告链接", "核验状态",
    "匹配度得分", "需求相关性得分", "时效性得分", "预算适配得分",
    "资格可达性得分", "信息完整度得分", "综合得分", "AI建议等级",
    "人工确认等级", "投标行动策略要点", "负责人", "状态", "备注",
]

# ---- 默认评分标准（教学示例，课堂可调整；同步写入 xlsx 与看板）----
DEFAULT_CRITERIA = [
    ["维度", "权重(教学示例)", "评分说明"],
    ["ICP匹配度（行业/区域/场景）", 25, "行业、区域、场景与《企业A_公司介绍.md》ICP要点逐项对照"],
    ["需求相关性（关键词命中）", 20, "命中核心关键词组的数量与权重"],
    ["时效性（距截止天数）", 15, "截止日期距今≥7天满分，临近递减，已过期0分"],
    ["预算适配", 15, "20万-500万元教学区间内满分，区间外降档"],
    ["资格可达性", 15, "对照模拟资质（质量管理体系/机电安装/安全生产培训）逐项评估"],
    ["信息完整度（核验状态）", 10, "已核验满分，部分核验减半，未核验/存疑低分"],
    ["等级阈值（教学默认，待人工确认）", "", "A≥80；B 60-79；C<60"],
]

GRADE_ORDER = {"A": 0, "B": 1, "C": 2}


def create_template():
    """按规范创建线索库模板。"""
    wb = Workbook()

    ws = wb.active
    ws.title = "线索总表"
    ws.append(HEADERS)
    header_fill = PatternFill("solid", fgColor="E8F1EB")
    header_font = Font(bold=True, color="315F4B")
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center")
    widths = [16, 28, 24, 10, 10, 12, 14, 14, 30, 10,
              10, 12, 10, 10, 12, 12, 10, 10, 10, 36, 10, 12, 16]
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[ws.cell(row=1, column=i).column_letter].width = w
    ws.freeze_panes = "A2"

    ws2 = wb.create_sheet("评分标准")
    for row in DEFAULT_CRITERIA:
        ws2.append(row)
    ws2.column_dimensions["A"].width = 30
    ws2.column_dimensions["B"].width = 16
    ws2.column_dimensions["C"].width = 60

    ws3 = wb.create_sheet("版本记录")
    ws3.append(["日期", "操作", "记录人", "说明"])
    ws3.append([TODAY, "初始化模板", "脚本自动", "由 05_script/build_leadboard.py 创建"])
    for col, w in zip("ABCD", [12, 14, 12, 50]):
        ws3.column_dimensions[col].width = w

    XLSX_PATH.parent.mkdir(parents=True, exist_ok=True)
    wb.save(XLSX_PATH)
    return wb


def read_leads(wb):
    """读取线索总表数据行（跳过空行），返回 dict 列表。"""
    ws = wb["线索总表"]
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        return []
    headers = [str(h).strip() if h is not None else "" for h in rows[0]]
    leads = []
    for row in rows[1:]:
        if row is None or all(v is None or str(v).strip() == "" for v in row):
            continue
        item = {}
        for k, v in zip(headers, row):
            item[k] = "" if v is None else str(v).strip()
        if not item.get("项目名称"):
            continue
        leads.append(item)
    return leads


def to_num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def build_stats(leads):
    total = len(leads)
    verified = sum(1 for x in leads if "已核验" in x.get("核验状态", ""))
    grades = {"A": 0, "B": 0, "C": 0}
    for x in leads:
        g = x.get("AI建议等级", "").strip().upper()[:1]
        if g in grades:
            grades[g] += 1
    deadlines = [x.get("报名/截止日期", "")[:10] for x in leads
                 if x.get("报名/截止日期", "") and x.get("报名/截止日期", "")[:10] >= TODAY]
    nearest = min(deadlines) if deadlines else ""
    return {"total": total, "verified": verified, "grades": grades,
            "nearestDeadline": nearest, "generatedAt": TODAY, "empty": total == 0}


def export_data_js(wb, leads, stats):
    ws = wb["评分标准"]
    criteria = [[("" if c is None else str(c)) for c in row] for row in ws.iter_rows(values_only=True)]
    leads_sorted = sorted(
        leads,
        key=lambda x: (GRADE_ORDER.get(x.get("AI建议等级", "").strip().upper()[:1], 9),
                       -(to_num(x.get("综合得分")) or 0)))
    leads_out = []
    for x in leads_sorted[:60]:
        leads_out.append({
            "id": x.get("线索ID", ""),
            "name": x.get("项目名称", ""),
            "buyer": x.get("采购主体", ""),
            "region": x.get("区域", ""),
            "budget": x.get("预算(万元)", ""),
            "deadline": x.get("报名/截止日期", ""),
            "platform": x.get("来源平台", ""),
            "link": x.get("公告链接", ""),
            "verify": x.get("核验状态", "") or "待核验",
            "score": to_num(x.get("综合得分")),
            "grade": x.get("AI建议等级", "").strip().upper()[:1] or "未定级",
            "strategy": x.get("投标行动策略要点", ""),
            "status": x.get("状态", "") or "待人工确认",
        })
    payload = {
        **stats,
        "leads": leads_out,
        "criteria": criteria,
        "note": "数据来源于 04_archive/线索库.xlsx；等级为AI建议等级，最终以人工确认为准。",
    }
    DATA_JS_PATH.parent.mkdir(parents=True, exist_ok=True)
    content = "// 由 05_script/build_leadboard.py 自动生成，请勿手工编辑\n"
    content += "// 数据来源：04_archive/线索库.xlsx\n"
    content += "window.LEADBOARD_DATA = " + json.dumps(payload, ensure_ascii=False, indent=2) + ";\n"
    DATA_JS_PATH.write_text(content, encoding="utf-8")


def main():
    created = False
    if XLSX_PATH.exists():
        wb = load_workbook(XLSX_PATH)
        if "线索总表" not in wb.sheetnames:
            print("错误：线索库.xlsx 缺少『线索总表』工作表", file=sys.stderr)
            sys.exit(1)
    else:
        wb = create_template()
        created = True

    leads = read_leads(wb)
    stats = build_stats(leads)
    export_data_js(wb, leads, stats)

    print(json.dumps({
        "status": "ok",
        "createdTemplate": created,
        "xlsx": str(XLSX_PATH.relative_to(ROOT)),
        "dataJs": str(DATA_JS_PATH.relative_to(ROOT)),
        "leads": stats["total"],
        "verified": stats["verified"],
        "grades": stats["grades"],
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
