# 脚本运行说明（案例1）

## make_dashboard.py（步骤 7 辅助脚本）

读取 `04_archive/线索库.xlsx` 的「线索数据」表，生成 `06_webapp/index.html` 线索工作看板（样式复用 `workbench-ui-template` 设计令牌）。

```bash
# 在案例根目录运行（使用已安装 openpyxl 的 Python 环境）
python3 05_script/make_dashboard.py
```

依赖：`openpyxl`（仅此一个第三方库，见 `requirements.txt`）。

说明：
- 线索库为空时生成"空态"看板骨架（供讲师课前预览 UI）；
- 课堂完成步骤 1—6、线索库写入数据后，再次运行即可一键重建带数据的看板；
- 步骤 7 首选由 WorkBuddy 按提示词直接生成看板；本脚本作为快速重建/兜底工具。

## requirements.txt

- `openpyxl`：读写 xlsx（本案例过程文件/线索库使用）。
