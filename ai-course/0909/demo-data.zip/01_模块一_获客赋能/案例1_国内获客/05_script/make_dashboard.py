#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
make_dashboard.py —— 案例1 步骤7 辅助脚本

从 04_archive/线索库.xlsx 的"线索数据"表读取线索，渲染生成
06_webapp/index.html（HTML 工作看板）。界面样式复用
workbench-ui-template 模板的 styles.css（设计令牌一致）。

用法：
    python3 05_script/make_dashboard.py            # 默认读取 04_archive/线索库.xlsx → 06_webapp/index.html

依赖：openpyxl（pip install openpyxl）
说明：本脚本为可选工具。第 7 步也可以用 WorkBuddy 直接生成看板；
      本脚本用于课堂快速重建（线索库更新后一键重出看板）。
"""
from pathlib import Path
import html
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
XLSX = ROOT / "04_archive" / "线索库.xlsx"
OUT = ROOT / "06_webapp" / "index.html"
SHEET = "线索数据"

LEVEL_COLORS = {"A": "green", "B": "amber", "C": "red"}


def main() -> int:
    try:
        import openpyxl
    except ImportError:
        print("缺少依赖 openpyxl，请先执行: pip install openpyxl", file=sys.stderr)
        return 1

    if not XLSX.exists():
        print(f"未找到线索库: {XLSX}", file=sys.stderr)
        return 1

    wb = openpyxl.load_workbook(XLSX, data_only=True)
    if SHEET not in wb.sheetnames:
        print(f"工作表 {SHEET} 不存在（当前表：{wb.sheetnames}）", file=sys.stderr)
        return 1
    ws = wb[SHEET]

    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        print("线索数据表为空（只有表头或无表头）。", file=sys.stderr)
        return 1

    headers = [str(h).strip() if h is not None else f"c{i}" for i, h in enumerate(rows[0])]
    records = []
    for r in rows[1:]:
        if all(c is None or str(c).strip() == "" for c in r):
            continue
        d = {headers[i]: ("" if (c is None or str(c).strip() == "None") else str(c).strip())
             for i, c in enumerate(r)}
        records.append(d)

    total = len(records)
    by_level = {"A": 0, "B": 0, "C": 0}
    cities, industries = set(), set()
    for d in records:
        lv = (d.get("线索等级") or "").upper()
        if lv in by_level:
            by_level[lv] += 1
        region = d.get("国家/地区") or d.get("地区") or ""
        if region:
            cities.add(region.split("/")[-1] if "/" in region else region)
        if d.get("行业"):
            industries.add(d["行业"])
    verified = sum(1 for d in records if d.get("主体核验信息"))

    rows_html = ""
    for d in records:
        lv = (d.get("线索等级") or "-").upper()
        badge = f'<span class="badge {LEVEL_COLORS.get(lv, "")}">{lv}</span>' if lv in LEVEL_COLORS else '<span class="badge">-</span>'
        rows_html += (
            "<tr>"
            f"<td><strong>{html.escape(d.get('企业名称',''))}</strong>"
            f"<small>{html.escape(d.get('线索ID',''))}</small></td>"
            f"<td>{html.escape(d.get('国家/地区',''))}</td>"
            f"<td>{html.escape(d.get('行业',''))}</td>"
            f"<td>{html.escape(d.get('企业规模',''))}</td>"
            f"<td>{badge}</td>"
            f"<td>{html.escape(d.get('需求信号',''))}</td>"
            f"<td>{html.escape(d.get('下一步行动',''))}</td>"
            f"<td><small>{html.escape(d.get('来源类型',''))}</small></td>"
            "</tr>"
        )

    # A 级焦点卡片
    a_cards = ""
    for d in records:
        if (d.get("线索等级") or "").upper() != "A":
            continue
        conf = d.get("置信度", "")
        try:
            pct = int(float(conf) * 100)
        except Exception:
            pct = None
        bar = (
            f'<div class="confidence-row"><span class="confidence-bar"><i style="width:{pct}%"></i></span>'
            f"<b>{conf}</b></div>" if pct is not None else ""
        )
        a_cards += (
            '<div class="record-card">'
            '<span class="badge green">A 级优先</span>'
            f"<h3>{html.escape(d.get('企业名称',''))}</h3>"
            f"<p><b>城市：</b>{html.escape(d.get('国家/地区',''))} ｜ <b>行业：</b>{html.escape(d.get('行业',''))}"
            f"<br><b>信号：</b>{html.escape(d.get('需求信号',''))}</p>"
            f"<footer>{bar}<span>{html.escape(d.get('下一步行动',''))}</span></footer>"
            "</div>"
        )

    empty_block = (
        '<div class="empty-state" id="emptyState"><div><div class="empty-icon">✦</div>'
        "<h2>线索库暂无数据</h2>"
        "<p>请先按分步提示词完成步骤1—6，并把候选名单写入 04_archive/线索库.xlsx，"
        "再运行本脚本或让 AI 重新生成看板。</p></div></div>"
    )

    data_json = json.dumps(
        {"total": total, "a": by_level["A"], "b": by_level["B"], "c": by_level["C"],
         "cities": len(cities), "verified": verified}, ensure_ascii=False)

    page = f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="color-scheme" content="light" />
<title>企业A · 国内获客线索工作看板</title>
<link rel="stylesheet" href="./styles.css" />
<style>
  .leads-table{{width:100%;border-collapse:collapse;font-size:13px}}
  .leads-table th,.leads-table td{{text-align:left;padding:10px 8px;border-bottom:1px solid var(--line);vertical-align:top}}
  .leads-table th{{color:var(--muted);font-weight:600;white-space:nowrap}}
  .leads-table td small{{display:block;color:var(--muted);margin-top:2px}}
  .filter-tabs{{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px}}
  .filter-tabs .chip{{border:1px solid var(--line);background:var(--paper);padding:6px 14px;border-radius:999px;
    cursor:pointer;font-size:13px;color:var(--ink)}}
  .filter-tabs .chip.active{{background:var(--green-soft);border-color:var(--green);color:var(--green-dark);font-weight:600}}
  .dist-bar{{display:flex;height:12px;border-radius:6px;overflow:hidden;margin-top:10px;background:var(--line)}}
  .dist-bar i{{display:block;height:100%}}
  .legend{{display:flex;gap:16px;margin-top:10px;font-size:12px;color:var(--muted)}}
  .legend b{{margin-right:4px}}
  .metric-card small{{font-size:12px}}
</style>
</head>
<body>
<div class="app-shell">
  <header class="topbar">
    <button class="brand" type="button">
      <span class="brand-mark">拓</span>
      <span><strong>华东智节 · 线索工作台</strong><small>国内网上获客 · 案例1</small></span>
    </button>
    <span class="local-pill" style="margin-left:auto"><i></i>教学基准日 2026-09-07</span>
  </header>

  <aside class="sidebar">
    <nav aria-label="主导航">
      <button class="nav-item active" type="button" data-view="dashboard"><span>◫</span>总览</button>
      <button class="nav-item" type="button" data-view="records"><span>◇</span>线索库 <b>{total}</b></button>
      <button class="nav-item" type="button" data-view="library"><span>▤</span>A级优先</button>
    </nav>
    <section class="sidebar-guide">
      <p class="eyebrow">获客闭环</p>
      <ol>
        <li><span>1</span>画像与规则</li>
        <li><span>2</span>专家搜索</li>
        <li><span>3</span>核验去重</li>
        <li><span>4</span>评分分级</li>
        <li><span>5</span>开发话术</li>
        <li><span>6</span>回写线索库</li>
        <li><span>7</span>工作看板</li>
      </ol>
    </section>
  </aside>

  <main class="main-content">
    <div class="page-head">
      <div>
        <p class="eyebrow">Overview</p>
        <h1>国内获客线索工作看板</h1>
        <p>企业A（华东智节工业设备）公开渠道获客 · 数据来源：高德POI / 官网 / 公网检索（仅课堂演示）</p>
      </div>
      <div class="actions"><span class="badge green">人工审核中</span></div>
    </div>

    <div class="metric-grid">
      <div class="metric-card"><span>候选总数</span><strong>{total}</strong><small>目标 20 条</small></div>
      <div class="metric-card"><span>A 级线索</span><strong>{by_level['A']}</strong><small>优先开发</small></div>
      <div class="metric-card"><span>B / C 级</span><strong>{by_level['B']} / {by_level['C']}</strong><small>培育与复审</small></div>
      <div class="metric-card"><span>覆盖城市</span><strong>{len(cities)}</strong><small>华东重点城市</small></div>
    </div>

    <div class="dashboard-grid">
      <div class="stack">
        <section class="panel">
          <div class="panel-header"><h2>等级分布</h2><p>A / B / C 三级 · 等级需人工确认</p></div>
          <div class="panel-body">
            <div class="dist-bar">
              <i style="width:{ (by_level['A']/total*100 if total else 0):.1f}%;background:var(--green)"></i>
              <i style="width:{ (by_level['B']/total*100 if total else 0):.1f}%;background:var(--amber)"></i>
              <i style="width:{ (by_level['C']/total*100 if total else 0):.1f}%;background:var(--red)"></i>
            </div>
            <div class="legend">
              <span><i style="display:inline-block;width:10px;height:10px;background:var(--green);border-radius:3px"></i> <b>A</b>{by_level['A']}</span>
              <span><i style="display:inline-block;width:10px;height:10px;background:var(--amber);border-radius:3px"></i> <b>B</b>{by_level['B']}</span>
              <span><i style="display:inline-block;width:10px;height:10px;background:var(--red);border-radius:3px"></i> <b>C</b>{by_level['C']}</span>
            </div>
          </div>
        </section>

        <section class="panel">
          <div class="panel-header"><h2>线索列表</h2><p>全部候选（已去重核验）· 点击等级筛选</p></div>
          <div class="panel-body">
            <div class="filter-tabs" id="filters">
              <button class="chip active" data-lv="">全部 ({total})</button>
              <button class="chip" data-lv="A">A级 ({by_level['A']})</button>
              <button class="chip" data-lv="B">B级 ({by_level['B']})</button>
              <button class="chip" data-lv="C">C级 ({by_level['C']})</button>
            </div>
            {('' if rows_html else empty_block)}
            <table class="leads-table" id="leadsTable" {'hidden' if not rows_html else ''}>
              <thead><tr><th>企业</th><th>区域</th><th>行业</th><th>规模</th><th>等级</th><th>需求信号</th><th>下一步</th><th>来源</th></tr></thead>
              <tbody>{rows_html}</tbody>
            </table>
          </div>
        </section>
      </div>

      <div class="stack">
        <section class="panel">
          <div class="panel-header"><h2>A 级优先线索</h2><p>最优等级 · 首次开发（电话/邮件）</p></div>
          <div class="panel-body">
            <div class="card-grid">{(a_cards if a_cards else empty_block)}</div>
          </div>
        </section>
        <section class="panel">
          <div class="panel-header"><h2>数据状态</h2><p>真实性需人工核验</p></div>
          <div class="panel-body">
            <div class="evidence-list">
              <div class="evidence-row"><h3>主体已核验<small>官网/公网</small></h3><span class="badge blue">{verified} 条</span><p>核验通过数</p><div class="row-actions"><span class="badge">核验中</span></div></div>
              <div class="evidence-row"><h3>人工确认状态<small>等级/负责人/触达</small></h3><span class="badge amber">待确认</span><p>AI 不得越权确认</p><div class="row-actions"><span class="badge">人工</span></div></div>
            </div>
            <div class="draft-notice" style="margin-top:14px"><span>!</span><p><strong>课堂演示边界：</strong>候选为真实企业公开信息，禁止对外触达，触达演练一律使用虚构示例。</p></div>
          </div>
        </section>
      </div>
    </div>
  </main>
</div>

<script>
  const DATA = {data_json};
  document.querySelectorAll('#filters .chip').forEach(chip => {{
    chip.addEventListener('click', () => {{
      document.querySelectorAll('#filters .chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      const lv = chip.dataset.lv;
      document.querySelectorAll('#leadsTable tbody tr').forEach(tr => {{
        const cell = tr.querySelector('td:nth-child(5) .badge');
        tr.hidden = lv !== '' && cell && cell.textContent.trim().charAt(0) !== lv;
      }});
    }});
  }});
</script>
</body>
</html>
"""
    OUT.write_text(page, encoding="utf-8")
    print(f"OK：已生成 {OUT}（{total} 条线索：A={by_level['A']} B={by_level['B']} C={by_level['C']}）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
