# 06_webapp｜HTML 工作看板目录

> 本目录存放本案例**步骤 7** 生成的工作看板（`index.html`）。

## 当前内容

- `index.html`：由 `05_script/make_dashboard.py` 生成的看板（当前为空态骨架，因线索库尚未写入数据）。
- `styles.css`：自案例内 `workbench-ui-template/styles.css` 复制的工作台样式（设计令牌一致）。

## 课堂使用流程

1. 完成步骤 1—6，候选名单写入 `04_archive/线索库.xlsx`；
2. 在案例根目录运行 `python3 05_script/make_dashboard.py`（或在 WorkBuddy 中按步骤 7 提示词让 AI 直接生成/更新 `index.html`）；
3. 浏览器打开本目录 `index.html` 查看线索工作看板（数据内嵌、样式本地，无网络依赖）。

## 风格说明

看板界面参考案例内 `workbench-ui-template/` 工作台模板：浅米绿画布 + 白纸面卡片 + 衬线标题；含概览指标卡、等级分布、线索列表（可筛选）、A 级优先卡片、7 步获客闭环导航。

## 注意事项

- 看板含真实企业公开信息时仅限课堂演示，禁止对外发布或触达；
- 不使用外部 CDN / 字体，页面可离线打开。
