@echo off
REM ============================================================
REM  Case 4 Dashboard - Quick Start (Windows)
REM  Double-click this file to start the local server and open
REM  the dashboard in your default browser.
REM  Requires: Python 3.8+ installed and on PATH.
REM  Stop: press Ctrl+C in the window, or close the window.
REM ============================================================

REM Switch to the case root directory (where this file now lives)
cd /d "%~dp0"

REM Check Python availability
where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Python not found. Please install Python 3.8+ first:
    echo         https://www.python.org/downloads/windows/
    echo         Remember to check "Add Python to PATH" during install.
    pause
    exit /b 1
)

echo Starting Case 4 dashboard server on http://localhost:8765 ...
python "05_script\serve_dashboard.py" %1

echo.
echo Server stopped.
pause
