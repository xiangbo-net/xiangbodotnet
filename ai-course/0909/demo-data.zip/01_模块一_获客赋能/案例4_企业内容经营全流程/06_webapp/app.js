/* ============================================================
   内容工作台 v3.0 · 前端逻辑
   ------------------------------------------------------------
   数据：优先 fetch("/api/data")（后端实时解析 04_archive CSV），
        失败（file:// 直开）时回退 data.js 快照。
   视图：#/dashboard #/topics #/schedule #/ledger #/settings
   交互：全局搜索 / chip 筛选 / 排序 / 折叠详情 / 详情对话框 /
        复制 / 导出 CSV / 刷新数据 / 新建选题（演示）
   ============================================================ */
(function () {
  "use strict";

  /* ---------- 工具 ---------- */
  var $ = function (sel, root) { return (root || document).querySelector(sel); };
  var $$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function shortType(t) {
    var map = {
      "行业内幕与专业判断": "行业内幕",
      "产品与解决方案优势": "产品优势",
      "案例成果与客户收益": "案例成果",
      "客户痛点": "客户痛点"
    };
    return map[t] || t || "未分类";
  }
  function statusBadge(status) {
    var s = status || "未知";
    var cls = s === "已发布" ? "green" : s === "排期中" ? "blue" : "amber";
    return '<span class="badge ' + cls + '">' + esc(s) + "</span>";
  }
  function channelBadges(channels) {
    if (!channels) return '<span class="badge">渠道待定</span>';
    return String(channels).split(/[\/、,，]/).filter(Boolean).map(function (c) {
      var cls = c.indexOf("公众号") >= 0 ? "green" : c.indexOf("官网") >= 0 ? "blue" : "red";
      return '<span class="badge ' + cls + '">' + esc(c.trim()) + "</span>";
    }).join("");
  }
  function todayStr() {
    var d = new Date();
    return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
  }

  /* ---------- Toast ---------- */
  var toastEl = $("#toast"), toastTimer;
  function showToast(text, isError) {
    toastEl.textContent = text;
    toastEl.classList.toggle("error", !!isError);
    toastEl.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.classList.remove("show"); }, 2600);
  }
  function copyText(text, okMsg) {
    function done() { showToast(okMsg || "已复制：" + (text.length > 24 ? text.slice(0, 24) + "…" : text)); }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(done, function () { legacyCopy(text, done); });
    } else { legacyCopy(text, done); }
  }
  function legacyCopy(text, done) {
    var ta = document.createElement("textarea");
    ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
    document.body.appendChild(ta); ta.select();
    try { document.execCommand("copy"); done(); } catch (e) { showToast("复制失败，请手动选择复制", true); }
    document.body.removeChild(ta);
  }
  function downloadCsv(relPath, name) {
    var a = document.createElement("a");
    a.href = relPath; a.download = name || "";
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    showToast("已开始下载：" + (name || relPath));
  }

  /* ---------- 状态 ---------- */
  var state = {
    data: { updatedAt: "", source: "—", topics: [], ledger: [] },
    view: "dashboard",
    topicKeyword: "", topicType: "", topicStatus: "", topicSort: "id-asc",
    scheduleKeyword: "", scheduleStatus: "", scheduleType: "", scheduleSortDesc: true, scheduleExpandAll: false,
    ledgerKeyword: "", ledgerChannel: ""
  };
  var VIEWS = ["dashboard", "topics", "schedule", "ledger", "settings"];

  /* ---------- 数据加载 ---------- */
  function normalize(raw) {
    return {
      updatedAt: raw.updatedAt || "—",
      source: raw.source || "snapshot",
      topics: (raw.topics || []).map(function (t) {
        return {
          id: t.id || "", type: t.type || "", title: t.title || "",
          formula: t.formula || "", audience: t.audience || "",
          materials: t.materials || "", channels: t.channels || "",
          status: t.status || "", risk: t.risk || ""
        };
      }),
      ledger: (raw.ledger || []).map(function (r) {
        return {
          date: r.date || "", weekday: r.weekday || "", id: r.id || "",
          type: r.type || "", topic: r.topic || "", channel: r.channel || "",
          derived: r.derived || "", status: r.status || "", title: r.title || "",
          link: r.link || "", publishTime: r.publishTime || "", note: r.note || ""
        };
      })
    };
  }
  function loadData(silent) {
    var pill = $("#sourcePill");
    var fetchPromise;
    try {
      if (typeof fetch !== "function") throw new Error("当前环境不支持 fetch");
      fetchPromise = fetch("/api/data", { cache: "no-store" });
    } catch (e) {
      fetchPromise = Promise.reject(e);
    }
    return fetchPromise
      .then(function (res) {
        if (!res.ok) throw new Error("HTTP " + res.status);
        return res.json();
      })
      .then(function (json) {
        state.data = normalize(json);
        pill.title = "数据来源：后端 /api/data（实时解析 04_archive CSV）";
        pill.childNodes[1].nodeValue = "后端动态数据";
        pill.classList.remove("off");
        renderAll();
        if (!silent) showToast("数据已刷新（后端动态）：" + state.data.updatedAt);
        return true;
      })
      .catch(function () {
        if (window.DASHBOARD_DATA) {
          state.data = normalize(window.DASHBOARD_DATA);
          state.data.source = "snapshot";
        }
        pill.title = "数据来源：本地 data.js 快照（未连接本地服务）";
        pill.childNodes[1].nodeValue = "本地快照";
        pill.classList.add("off");
        renderAll();
        if (!silent) showToast("未连接本地服务，已加载本地快照（双击根目录启动脚本可启用动态数据）", true);
        return false;
      });
  }

  /* ---------- 视图路由 ---------- */
  function switchView(view, opts) {
    if (VIEWS.indexOf(view) < 0) view = "dashboard";
    state.view = view;
    $$(".view-panel").forEach(function (p) { p.hidden = p.getAttribute("data-view-panel") !== view; });
    $$(".nav-item[data-view]").forEach(function (b) { b.classList.toggle("active", b.getAttribute("data-view") === view); });
    if (!opts || !opts.noHash) {
      var target = "#/" + view;
      if (location.hash !== target) history.replaceState(null, "", target);
    }
    var focusMap = { topics: "#topicSearch", schedule: "#scheduleSearch", ledger: "#ledgerSearch" };
    if (focusMap[view] && (!opts || !opts.keepFocus)) {
      try { $(focusMap[view]).focus(); } catch (e) {}
    }
    renderAll();
  }
  function viewFromHash() {
    var m = (location.hash || "").match(/^#\/([a-z]+)/);
    return m && VIEWS.indexOf(m[1]) >= 0 ? m[1] : "dashboard";
  }

  /* ============================================================
     渲染：总览
     ============================================================ */
  function renderDashboard() {
    var d = state.data;
    var ledger = d.ledger.slice().sort(function (a, b) { return (b.date || "").localeCompare(a.date || ""); });
    var published = d.ledger.filter(function (r) { return r.status === "已发布"; });
    var channels = {};
    d.ledger.forEach(function (r) {
      String((r.channel || "") + "/" + (r.derived || "")).split(/[\/、,，]/).filter(Boolean).forEach(function (c) { channels[c.trim()] = 1; });
    });

    /* 指标卡 */
    $("#dashMetrics").innerHTML =
      metricCard("本月计划", ledger.length, "台账记录总数") +
      metricCard("已发布", published.length, "占比 " + (ledger.length ? Math.round(published.length / ledger.length * 100) : 0) + "%") +
      metricCard("选题储备", d.topics.length, "选题库在库") +
      metricCard("覆盖渠道", Object.keys(channels).length, Object.keys(channels).join(" / ") || "—");

    /* 焦点卡：最新一条台账 */
    var latest = ledger[0];
    if (latest) {
      $("#dashFocusTop").innerHTML = statusBadge(latest.status) +
        '<span class="badge blue">' + esc(shortType(latest.type)) + "</span>" +
        (latest.link ? '<span class="badge green">已回填链接</span>' : '<span class="badge amber">链接待补充</span>');
      $("#dashFocusTitle").textContent = latest.title || latest.topic || "（待生成标题）";
      $("#dashFocusText").textContent =
        latest.date + "（周" + latest.weekday + "）｜主渠道：" + latest.channel +
        (latest.derived ? "｜衍生：" + latest.derived : "") + "｜" + latest.id;
      var rate = ledger.length ? Math.round(published.length / ledger.length * 100) : 0;
      $("#dashFocusActions").innerHTML =
        (latest.link ? '<a class="button primary" href="' + esc(latest.link) + '" target="_blank" rel="noopener">打开发布原文</a>' : "") +
        '<button class="button secondary" type="button" data-view-jump="ledger">查看发布台账</button>' +
        '<span class="badge">本月完成率 ↓</span>' +
        '<div class="confidence-row" style="flex:1;max-width:220px"><span class="confidence-bar"><i style="width:' + rate + '%"></i></span></div>';
    } else {
      $("#dashFocusTop").innerHTML = '<span class="badge amber">暂无台账</span>';
      $("#dashFocusTitle").textContent = "还没有发布记录";
      $("#dashFocusText").textContent = "先在选题库立项，再排入内容排期，发布后回填台账。";
      $("#dashFocusActions").innerHTML = '<button class="button primary" type="button" data-view-jump="topics">进入选题库</button>';
    }

    /* 最近发布卡片 */
    $("#dashRecentCards").innerHTML = ledger.slice(0, 3).map(function (r) {
      return '<div class="record-card" data-record="ledger:' + esc(r.id) + '">' +
        statusBadge(r.status) +
        "<h3>" + esc(r.title || r.topic || "（待生成标题）") + "</h3>" +
        "<p>" + esc(r.note || (r.topic + "｜" + shortType(r.type))) + "</p>" +
        "<footer><strong>" + esc((r.date || "").slice(5)) + "</strong><span>" + esc(r.channel || "") + "</span><span>·</span><span>" + esc(r.id) + "</span></footer>" +
        "</div>";
    }).join("") || '<div class="empty-state" style="grid-column:1/-1;min-height:180px"><div><h2>暂无发布</h2><p>台账为空时这里显示空状态。</p></div></div>';

    /* 选题储备行（最新 3 条，点击开详情对话框） */
    $("#dashTopicRows").innerHTML = d.topics.slice(-3).reverse().map(function (t) {
      return '<div class="evidence-row collapsible" data-record="topic:' + esc(t.id) + '">' +
        '<div class="row-head">' +
        "<h3>" + esc(t.title) + "<small>" + esc(t.id) + " · 素材：" + esc(t.materials || "—") + " · " + esc(t.audience || "受众待确认") + "</small></h3>" +
        '<span class="badge blue">' + esc(shortType(t.type)) + "</span>" + statusBadge(t.status) + channelBadges(t.channels) +
        '<span class="row-actions"><button class="button small secondary" type="button" data-act="open-dialog" data-value="topic:' + esc(t.id) + '">查看详情</button></span>' +
        "</div></div>";
    }).join("") || '<div class="empty-state" style="min-height:180px"><div><h2>暂无选题</h2><p>选题库为空时这里显示空状态。</p></div></div>';

    /* 发布节奏 pipeline（对照真实今天） */
    var today = todayStr();
    var byDate = d.ledger.slice().sort(function (a, b) { return (a.date || "").localeCompare(b.date || ""); });
    $("#dashPipeline").innerHTML = byDate.slice(0, 6).map(function (r) {
      var cls = r.date < today ? "done" : r.date === today ? "active" : "";
      var label = (r.date || "").slice(5).replace("-", "/");
      return '<div class="pipeline-step ' + cls + '"><span>' + esc(label) + "</span><div><strong>" +
        esc((r.title || r.topic || "待生成").slice(0, 22)) + "</strong><small>" +
        esc(r.channel || "") + (r.date === today ? " · 今天" : r.date < today ? " · 已完成" : " · 计划中") +
        "</small></div></div>";
    }).join("") || '<p style="margin:0;color:var(--muted);font-size:11px">暂无排期数据。</p>';

    /* 分布面板：类型 + 渠道（可点击跳转筛选） */
    var typeCount = {}, channelCount = {};
    d.ledger.forEach(function (r) {
      if (r.type) typeCount[r.type] = (typeCount[r.type] || 0) + 1;
      String((r.channel || "") + "/" + (r.derived || "")).split(/[\/、,，]/).filter(Boolean).forEach(function (c) {
        c = c.trim(); channelCount[c] = (channelCount[c] || 0) + 1;
      });
    });
    var total = d.ledger.length || 1;
    function distRows(counts, view, filterKey) {
      return Object.keys(counts).sort(function (a, b) { return counts[b] - counts[a]; }).map(function (k) {
        var pct = Math.round(counts[k] / total * 100);
        return '<div class="confidence-row" style="margin-bottom:12px;cursor:pointer" data-dist="' + esc(view) + '" data-dist-value="' + esc(k) + '" title="点击跳转筛选">' +
          '<span style="width:5em;font-size:10px;color:var(--muted)">' + esc(shortType(k) === k ? k : shortType(k)) + "</span>" +
          '<span class="confidence-bar"><i style="width:' + pct + '%"></i></span>' +
          '<span style="font-size:10px;color:var(--green-dark);white-space:nowrap">' + counts[k] + " 条</span></div>";
      }).join("");
    }
    $("#dashDistPanel").innerHTML =
      '<p class="eyebrow" style="margin-bottom:12px">创作类型分布</p>' + distRows(typeCount, "topics", "type") +
      '<p class="eyebrow" style="margin:16px 0 12px">渠道分布</p>' + distRows(channelCount, "ledger", "channel");
  }
  function metricCard(label, value, sub) {
    return '<div class="metric-card"><span>' + esc(label) + "</span><strong>" + esc(value) + "</strong><small>" + esc(sub) + "</small></div>";
  }

  /* ============================================================
     渲染：选题库
     ============================================================ */
  function filteredTopics() {
    var kw = state.topicKeyword.trim().toLowerCase();
    var list = state.data.topics.filter(function (t) {
      if (state.topicType && t.type !== state.topicType) return false;
      if (state.topicStatus && t.status !== state.topicStatus) return false;
      if (kw && (t.title + " " + t.audience + " " + t.materials + " " + t.id + " " + t.formula).toLowerCase().indexOf(kw) < 0) return false;
      return true;
    });
    var sorters = {
      "id-asc": function (a, b) { return (a.id || "").localeCompare(b.id || ""); },
      "id-desc": function (a, b) { return (b.id || "").localeCompare(a.id || ""); },
      "type": function (a, b) { return (a.type || "").localeCompare(b.type || "") || (a.id || "").localeCompare(b.id || ""); },
      "status": function (a, b) { return (a.status || "").localeCompare(b.status || "") || (a.id || "").localeCompare(b.id || ""); }
    };
    return list.sort(sorters[state.topicSort] || sorters["id-asc"]);
  }
  function renderTopics() {
    /* chips（带计数） */
    var types = {}, statuses = {};
    state.data.topics.forEach(function (t) {
      if (t.type) types[t.type] = (types[t.type] || 0) + 1;
      if (t.status) statuses[t.status] = (statuses[t.status] || 0) + 1;
    });
    renderChipGroup("#topicTypeChips", "type", types, state.topicType, shortType);
    renderChipGroup("#topicStatusChips", "status", statuses, state.topicStatus);

    var list = filteredTopics();
    $("#topicCount").innerHTML = "共 <b>" + list.length + "</b> / " + state.data.topics.length + " 条";

    $("#topicList").innerHTML = list.map(function (t) {
      var formula = t.formula ? t.formula.split(/[＋+]/).map(function (s) { return s.trim(); }).filter(Boolean)
        .map(function (s) { return '<span class="formula-step">' + esc(s) + "</span>"; })
        .join('<span class="formula-sep">＋</span>') : "（未填写）";
      return '<div class="evidence-row collapsible" data-record="topic:' + esc(t.id) + '">' +
        '<div class="row-head">' +
        "<h3>" + esc(t.title) + "<small>" + esc(t.id) + " · 素材：" + esc(t.materials || "—") + " · " + esc(t.audience || "受众待确认") + "</small></h3>" +
        '<span class="badge blue">' + esc(shortType(t.type)) + "</span>" + statusBadge(t.status) + channelBadges(t.channels) +
        '<span class="row-actions">' +
        '<button class="row-toggle" type="button">详情 ▾</button>' +
        "</span></div>" +
        '<p class="row-summary">公式：" + esc(t.formula || "未填写") + "</p>' +
        '<dl class="row-detail" hidden>' +
        "<dt>选题公式</dt><dd><span class=\"formula-steps\">" + formula + "</span></dd>" +
        "<dt>目标受众</dt><dd>" + esc(t.audience || "待确认") + "</dd>" +
        "<dt>适用渠道</dt><dd>" + channelBadges(t.channels) + "</dd>" +
        "<dt>参考素材</dt><dd>" + esc(t.materials || "待补充") + "</dd>" +
        "<dt>风险提示</dt><dd>" + esc(t.risk || "口径以品牌与内容规范为准") + "</dd>" +
        '<div class="row-detail-actions">' +
        '<button class="button small secondary" type="button" data-act="jump-schedule" data-value="' + esc(t.title) + '">查看对应排期</button>' +
        '<button class="button small secondary" type="button" data-act="copy-topic" data-value="' + esc(t.id) + '">复制选题与公式</button>' +
        '<button class="button small tertiary" type="button" data-act="open-dialog" data-value="topic:' + esc(t.id) + '">大窗查看</button>' +
        "</div></dl></div>";
    }).join("") || '<div class="empty-state"><div><div class="empty-icon">◇</div><h2>没有匹配的选题</h2><p>调整筛选条件，或清空筛选后重试。</p><button class="button primary" type="button" data-act="clear-topic-filter">清空筛选</button></div></div>';
  }
  function renderChipGroup(rootSel, key, counts, activeValue, labelFn, totalRecords) {
    var root = $(rootSel);
    if (!root) return;
    var html = '<span class="chip-group-label">' + esc(root.getAttribute("data-key") === "type" ? "类型" : root.getAttribute("data-key") === "status" ? "状态" : "渠道") + "</span>";
    var total = typeof totalRecords === "number" ? totalRecords : Object.keys(counts).reduce(function (n, k) { return n + counts[k]; }, 0);
    html += chipHtml(key, "", "全部", total, !activeValue);
    Object.keys(counts).sort().forEach(function (k) {
      html += chipHtml(key, k, labelFn ? labelFn(k) : k, counts[k], activeValue === k);
    });
    root.innerHTML = html;
  }
  function chipHtml(key, value, label, count, active) {
    return '<button class="chip' + (active ? " active" : "") + '" type="button" data-filter="' + esc(key) + '" data-value="' + esc(value) + '">' +
      esc(label) + " <b>" + count + "</b></button>";
  }

  /* ============================================================
     渲染：内容排期
     ============================================================ */
  function filteredSchedule() {
    var kw = state.scheduleKeyword.trim().toLowerCase();
    var list = state.data.ledger.filter(function (r) {
      if (state.scheduleStatus && r.status !== state.scheduleStatus) return false;
      if (state.scheduleType && r.type !== state.scheduleType) return false;
      if (kw && (r.topic + " " + r.title + " " + r.id + " " + r.date).toLowerCase().indexOf(kw) < 0) return false;
      return true;
    });
    list.sort(function (a, b) {
      var cmp = (a.date || "").localeCompare(b.date || "");
      return state.scheduleSortDesc ? -cmp : cmp;
    });
    return list;
  }
  function renderSchedule() {
    /* 类型下拉选项 */
    var sel = $("#scheduleTypeSelect");
    var types = {};
    state.data.ledger.forEach(function (r) { if (r.type) types[r.type] = 1; });
    var cur = state.scheduleType;
    sel.innerHTML = '<option value="">全部类型</option>' + Object.keys(types).sort().map(function (t) {
      return '<option value="' + esc(t) + '"' + (t === cur ? " selected" : "") + ">" + esc(shortType(t)) + "（" + esc(t) + "）</option>";
    }).join("");
    sel.value = cur;

    var statuses = {};
    state.data.ledger.forEach(function (r) { if (r.status) statuses[r.status] = (statuses[r.status] || 0) + 1; });
    renderChipGroup("#scheduleStatusChips", "status", statuses, state.scheduleStatus);

    var list = filteredSchedule();
    var today = todayStr();
    $("#scheduleCount").innerHTML = "共 <b>" + list.length + "</b> / " + state.data.ledger.length + " 条";
    $("#scheduleSortBtn").textContent = state.scheduleSortDesc ? "按日期 ↓ 倒序" : "按日期 ↑ 正序";
    $("#scheduleExpandBtn").textContent = state.scheduleExpandAll ? "全部收起" : "全部展开";

    $("#scheduleList").innerHTML = list.map(function (r) {
      var topic = state.data.topics.filter(function (t) { return t.title === r.topic; })[0] || {};
      return '<div class="evidence-row collapsible' + (state.scheduleExpandAll ? " open" : "") + '" data-record="ledger:' + esc(r.id) + '">' +
        '<div class="row-head">' +
        "<h3>" + esc(r.topic || "（待确认选题）") +
        "<small>" + esc(r.date) + " 周" + esc(r.weekday) + " · " + esc(r.id) + " · 主渠道：" + esc(r.channel) + "</small></h3>" +
        (r.date === today ? '<span class="badge blue">今天</span>' : "") +
        '<span class="badge blue">' + esc(shortType(r.type)) + "</span>" + statusBadge(r.status) +
        (r.derived ? '<span class="badge">衍生：' + esc(r.derived) + "</span>" : '<span class="badge">无衍生</span>') +
        '<span class="row-actions"><button class="row-toggle" type="button">详情 ' + (state.scheduleExpandAll ? "▴" : "▾") + "</button></span>" +
        "</div>" +
        '<p class="row-summary">' + (r.title ? "标题：" + esc(r.title) : "标题待生成，按第三步工作流创作") + "</p>" +
        '<dl class="row-detail"' + (state.scheduleExpandAll ? "" : " hidden") + ">" +
        "<dt>标题</dt><dd>" + esc(r.title || "（待生成）") + "</dd>" +
        "<dt>创作类型</dt><dd>" + esc(r.type) + "</dd>" +
        "<dt>主渠道</dt><dd>" + channelBadges(r.channel) + "</dd>" +
        "<dt>衍生渠道</dt><dd>" + esc(r.derived || "未设置") + "</dd>" +
        "<dt>发布链接</dt><dd>" + (r.link ? '<a class="action-link" href="' + esc(r.link) + '" target="_blank" rel="noopener">' + esc(r.link) + "</a>" : "（待回填）") + "</dd>" +
        "<dt>风险提示</dt><dd>" + esc(topic.risk || "—") + "</dd>" +
        '<div class="row-detail-actions">' +
        (r.link
          ? '<a class="button small primary" href="' + esc(r.link) + '" target="_blank" rel="noopener">打开发布原文</a>' +
            '<button class="button small secondary" type="button" data-act="copy-link" data-value="' + esc(r.link) + '">复制链接</button>'
          : '<span class="badge amber">发布后回填链接</span>') +
        '<button class="button small secondary" type="button" data-act="jump-topic" data-value="' + esc(r.topic) + '">查看对应选题</button>' +
        '<button class="button small tertiary" type="button" data-act="open-dialog" data-value="ledger:' + esc(r.id) + '">大窗查看</button>' +
        "</div></dl></div>";
    }).join("") || '<div class="empty-state"><div><div class="empty-icon">▤</div><h2>没有匹配的排期</h2><p>调整筛选条件，或清空筛选后重试。</p><button class="button primary" type="button" data-act="clear-schedule-filter">清空筛选</button></div></div>';
  }

  /* ============================================================
     渲染：发布台账
     ============================================================ */
  function filteredLedger() {
    var kw = state.ledgerKeyword.trim().toLowerCase();
    return state.data.ledger.filter(function (r) {
      if (state.ledgerChannel && (r.channel + " " + r.derived).indexOf(state.ledgerChannel) < 0) return false;
      if (kw && (r.title + " " + r.topic + " " + r.id + " " + r.date + " " + r.channel).toLowerCase().indexOf(kw) < 0) return false;
      return true;
    }).sort(function (a, b) { return (b.date || "").localeCompare(a.date || ""); });
  }
  function renderLedger() {
    var channels = {};
    state.data.ledger.forEach(function (r) {
      String((r.channel || "") + "/" + (r.derived || "")).split(/[\/、,，]/).filter(Boolean).forEach(function (c) {
        c = c.trim(); channels[c] = (channels[c] || 0) + 1;
      });
    });
    renderChipGroup("#ledgerChannelChips", "channel", channels, state.ledgerChannel, null, state.data.ledger.length);

    var list = filteredLedger();
    $("#ledgerCount").innerHTML = "共 <b>" + list.length + "</b> / " + state.data.ledger.length + " 条";

    $("#ledgerList").innerHTML = list.map(function (r) {
      return '<div class="evidence-row collapsible" data-record="ledger:' + esc(r.id) + '">' +
        '<div class="row-head">' +
        "<h3>" + esc(r.title || r.topic) +
        "<small>" + esc(r.date) + " 周" + esc(r.weekday) + " · " + esc(r.id) + " · " + esc(r.channel) + "</small></h3>" +
        statusBadge(r.status) + channelBadges(r.channel) +
        (r.link ? '<span class="badge green">已回填链接</span>' : '<span class="badge amber">链接待补充</span>') +
        '<span class="row-actions">' +
        (r.link ? '<a class="button small primary" href="' + esc(r.link) + '" target="_blank" rel="noopener">打开原文</a>' : "") +
        '<button class="row-toggle" type="button">详情 ▾</button>' +
        "</span></div>" +
        '<p class="row-summary">选题：' + esc(r.topic) + "｜" + esc(shortType(r.type)) + (r.derived ? "｜衍生：" + esc(r.derived) : "") + "｜发布 " + esc(r.publishTime || "—") + "</p>" +
        '<dl class="row-detail" hidden>' +
        "<dt>发布链接</dt><dd>" + (r.link ? '<a class="action-link" href="' + esc(r.link) + '" target="_blank" rel="noopener">' + esc(r.link) + "</a>" : "（待回填）") + "</dd>" +
        "<dt>标题</dt><dd>" + esc(r.title || "—") + "</dd>" +
        "<dt>推荐选题</dt><dd>" + esc(r.topic) + "</dd>" +
        "<dt>创作类型</dt><dd>" + esc(r.type) + "</dd>" +
        "<dt>发布时间</dt><dd>" + esc(r.publishTime || "—") + "</dd>" +
        "<dt>备注</dt><dd>" + esc(r.note || "—") + "</dd>" +
        '<div class="row-detail-actions">' +
        '<button class="button small secondary" type="button" data-act="copy-title" data-value="' + esc(r.title) + '">复制标题</button>' +
        (r.link ? '<button class="button small secondary" type="button" data-act="copy-link" data-value="' + esc(r.link) + '">复制链接</button>' : "") +
        '<button class="button small secondary" type="button" data-view-jump="schedule">查看排期</button>' +
        '<button class="button small tertiary" type="button" data-act="open-dialog" data-value="ledger:' + esc(r.id) + '">大窗查看</button>' +
        "</div></dl></div>";
    }).join("") || '<div class="empty-state"><div><div class="empty-icon">↻</div><h2>没有匹配的台账记录</h2><p>调整渠道筛选或搜索词，或清空筛选后重试。</p><button class="button primary" type="button" data-act="clear-ledger-filter">清空筛选</button></div></div>';
  }

  /* ============================================================
     渲染：数据与设置
     ============================================================ */
  function renderSettings() {
    var d = state.data;
    $("#settingsVerifyText").textContent =
      "选题库 " + d.topics.length + " 条 ｜ 台账 " + d.ledger.length + " 条 ｜ 数据更新于 " + d.updatedAt +
      " ｜ 来源：" + (d.source === "api" ? "后端 /api/data（实时解析 CSV）" : "本地 data.js 快照");
    $("#settingsVerifyCode").textContent =
      "04_archive/内容选题库.csv → topics[" + d.topics.length + "]\n" +
      "04_archive/内容经营台账.csv → ledger[" + d.ledger.length + "]";
  }

  /* ---------- 侧栏计数 + 总渲染 ---------- */
  function renderAll() {
    $("#navTopicCount").textContent = state.data.topics.length;
    $("#navScheduleCount").textContent = state.data.ledger.length;
    $("#navLedgerCount").textContent = state.data.ledger.filter(function (r) { return r.status === "已发布"; }).length;
    renderDashboard();
    renderTopics();
    renderSchedule();
    renderLedger();
    renderSettings();
  }

  /* ============================================================
     详情对话框
     ============================================================ */
  function findRecord(token) {
    var parts = String(token).split(":");
    if (parts[0] === "topic") {
      return { kind: "topic", rec: state.data.topics.filter(function (t) { return t.id === parts.slice(1).join(":"); })[0] };
    }
    return { kind: "ledger", rec: state.data.ledger.filter(function (r) { return r.id === parts.slice(1).join(":"); })[0] };
  }
  function openRecordDialog(token) {
    var found = findRecord(token);
    var rec = found.rec;
    if (!rec) { showToast("记录不存在：" + token, true); return; }
    var isTopic = found.kind === "topic";
    var dlg = $("#recordDialog");
    $("#recordDialogEyebrow").textContent = isTopic ? "Topic Detail" : "Ledger Detail";
    $("#recordDialogTitle").textContent = isTopic ? (rec.title || rec.id) : (rec.title || rec.topic || rec.id);
    $("#recordDialogSub").textContent = (isTopic ? "选题库记录" : "台账记录") + " · " + rec.id;

    function row(label, value) {
      return "<dt>...".replace("...", "") ? "<dt>" + esc(label) + "</dt><dd>" + value + "</dd>" : "";
    }
    var rows = "";
    if (isTopic) {
      var formula = rec.formula ? rec.formula.split(/[＋+]/).map(function (s) { return s.trim(); }).filter(Boolean)
        .map(function (s) { return '<span class="formula-step">' + esc(s) + "</span>"; })
        .join('<span class="formula-sep">＋</span>') : "（未填写）";
      rows = row("选题公式", '<span class="formula-steps">' + formula + "</span>") +
        row("创作类型", esc(rec.type)) + row("状态", statusBadge(rec.status)) +
        row("目标受众", esc(rec.audience || "待确认")) + row("适用渠道", channelBadges(rec.channels)) +
        row("参考素材", esc(rec.materials || "待补充")) + row("风险提示", esc(rec.risk || "口径以品牌与内容规范为准"));
    } else {
      rows = row("日期", esc(rec.date + "（周" + rec.weekday + "）")) + row("内容 ID", esc(rec.id)) +
        row("创作类型", esc(rec.type)) + row("推荐选题", esc(rec.topic)) +
        row("主渠道", channelBadges(rec.channel)) + row("衍生渠道", esc(rec.derived || "未设置")) +
        row("状态", statusBadge(rec.status)) + row("标题", esc(rec.title || "（待生成）")) +
        row("发布时间", esc(rec.publishTime || "—")) +
        row("发布链接", rec.link ? '<a class="action-link" href="' + esc(rec.link) + '" target="_blank" rel="noopener">' + esc(rec.link) + "</a>" : "（待回填）") +
        row("备注", esc(rec.note || "—"));
    }
    $("#recordDialogBody").innerHTML = '<dl class="row-detail" style="grid-template-columns:7em 1fr">' + rows + "</dl>";
    var primaryBtn = $("#recordDialogPrimary");
    primaryBtn.onclick = null;
    primaryBtn.textContent = !isTopic && rec.link ? "打开发布原文" : "复制全部字段";
    primaryBtn.setAttribute("data-act", !isTopic && rec.link ? "copy-link" : "copy-record");
    primaryBtn.setAttribute("data-value", !isTopic && rec.link ? rec.link : token);
    $("#recordDialogCopy").setAttribute("data-value", token);
    dlg.showModal();
  }
  function recordToText(token) {
    var found = findRecord(token);
    var rec = found.rec;
    if (!rec) return "";
    return Object.keys(rec).map(function (k) { return k + "：" + (rec[k] || "—"); }).join("\n");
  }

  /* ============================================================
     事件绑定
     ============================================================ */
  function bindEvents() {
    /* 导航与视图跳转 */
    document.addEventListener("click", function (e) {
      var nav = e.target.closest(".nav-item[data-view], [data-view-jump]");
      if (nav) {
        var v = nav.getAttribute("data-view") || nav.getAttribute("data-view-jump");
        switchView(v, { keepFocus: !!nav.closest(".panel") });
        return;
      }
      /* 分布条点击 → 跳转对应视图并筛选 */
      var dist = e.target.closest("[data-dist]");
      if (dist) {
        var v2 = dist.getAttribute("data-dist"), val = dist.getAttribute("data-dist-value") || "";
        if (v2 === "topics") { state.topicType = val; state.topicStatus = ""; }
        if (v2 === "ledger") { state.ledgerChannel = val; }
        switchView(v2, { keepFocus: true });
        showToast("已跳转并按「" + val + "」筛选");
        return;
      }
      /* 行点击（标题/整行）→ 切换折叠；卡片/详情按钮 → 打开对话框 */
      var toggleBtn = e.target.closest(".row-toggle");
      var card = e.target.closest(".record-card[data-record]");
      var detailBtn = e.target.closest('[data-act="open-dialog"]');
      if (card) { openRecordDialog(card.getAttribute("data-record")); return; }
      if (detailBtn) { openRecordDialog(detailBtn.getAttribute("data-value")); return; }
      if (toggleBtn || e.target.closest(".row-head h3")) {
        var rowEl = e.target.closest(".evidence-row.collapsible");
        if (rowEl && !e.target.closest("a, button:not(.row-toggle)")) {
          var detail = rowEl.querySelector(".row-detail");
          var open = detail.hasAttribute("hidden");
          if (open) detail.removeAttribute("hidden"); else detail.setAttribute("hidden", "");
          rowEl.classList.toggle("open", open);
          var btn = rowEl.querySelector(".row-toggle");
          if (btn) btn.textContent = (open ? "详情 ▴" : "详情 ▾");
        }
        return;
      }
      /* chip 筛选 */
      var chip = e.target.closest(".chip[data-filter]");
      if (chip) {
        var key = chip.getAttribute("data-filter"), val2 = chip.getAttribute("data-value") || "";
        var groupRoot = chip.closest(".chip-group");
        var groupKey = groupRoot ? groupRoot.getAttribute("data-key") : key;
        $$(groupRoot ? groupRoot.getAttribute("id") ? "#" + groupRoot.id : ".chip-group" : ".chip-group").forEach(function () {});
        /* 应用到对应状态字段 */
        var viewPanel = chip.closest(".view-panel");
        var panelName = viewPanel ? viewPanel.getAttribute("data-view-panel") : "";
        if (panelName === "topics") {
          if (groupKey === "type") state.topicType = val2; else state.topicStatus = val2;
          renderTopics();
        } else if (panelName === "schedule") {
          state.scheduleStatus = val2; renderSchedule();
        } else if (panelName === "ledger") {
          state.ledgerChannel = val2; renderLedger();
        }
        return;
      }
      /* 通用 data-act 按钮 */
      var actBtn = e.target.closest("[data-act]");
      if (actBtn) {
        var act = actBtn.getAttribute("data-act"), val3 = actBtn.getAttribute("data-value") || "";
        if (act === "copy-link") copyText(val3, "发布链接已复制");
        else if (act === "copy-title") copyText(val3, "标题已复制");
        else if (act === "copy-record") copyText(recordToText(val3), "全部字段已复制");
        else if (act === "copy-topic") {
          var f = findRecord("topic:" + val3);
          copyText(f.rec ? "【" + f.rec.id + "】" + f.rec.title + "\n公式：" + f.rec.formula + "\n受众：" + f.rec.audience : "", "选题与公式已复制");
        }
        else if (act === "jump-schedule") { state.scheduleKeyword = val3; state.scheduleStatus = ""; state.scheduleType = ""; $("#scheduleSearch").value = val3; switchView("schedule", { keepFocus: true }); showToast("已按选题筛选排期：" + val3.slice(0, 18) + "…"); }
        else if (act === "jump-topic") { state.topicKeyword = val3; state.topicType = ""; state.topicStatus = ""; $("#topicSearch").value = val3; switchView("topics", { keepFocus: true }); showToast("已按选题筛选选题库"); }
        else if (act === "clear-topic-filter") { clearTopicFilter(); }
        else if (act === "clear-schedule-filter") { clearScheduleFilter(); }
        else if (act === "clear-ledger-filter") { clearLedgerFilter(); }
        return;
      }
    });

    /* 对话框 */
    $$("[data-open-dialog]").forEach(function (b) {
      b.addEventListener("click", function () {
        var id = b.getAttribute("data-open-dialog");
        var dlg = document.getElementById(id);
        if (dlg) dlg.showModal();
      });
    });
    $$("[data-close-dialog]").forEach(function (b) {
      b.addEventListener("click", function () { b.closest("dialog").close(); });
    });
    $("#recordDialogCopy").addEventListener("click", function () {
      copyText(recordToText(this.getAttribute("data-value")), "全部字段已复制");
    });

    /* 新建选题（演示） */
    $("#newTopicForm").addEventListener("submit", function (e) {
      e.preventDefault();
      var fd = new FormData(this);
      var n = state.data.topics.length + 1;
      var id = "TOPIC-2026" + String(n).padStart(3, "0");
      state.data.topics.push({
        id: id, type: fd.get("type") || "", title: fd.get("title") || "",
        formula: fd.get("formula") || "", audience: fd.get("audience") || "",
        materials: "（演示新增）", channels: fd.get("channels") || "公众号",
        status: "排期中", risk: "课堂演示数据：未写入 CSV，刷新数据后恢复。"
      });
      this.reset();
      document.getElementById("newTopicDialog").close();
      renderAll();
      switchView("topics", { keepFocus: true });
      showToast("已加入选题库（仅演示）：" + id);
    });

    /* 搜索框 */
    function bindSearch(inputSel, setter) {
      $(inputSel).addEventListener("input", function () { setter(this.value); });
    }
    bindSearch("#topicSearch", function (v) { state.topicKeyword = v; renderTopics(); });
    bindSearch("#scheduleSearch", function (v) { state.scheduleKeyword = v; renderSchedule(); });
    bindSearch("#ledgerSearch", function (v) { state.ledgerKeyword = v; renderLedger(); });

    /* 全局搜索：作用于当前列表视图 */
    $("#globalSearch").addEventListener("input", function () {
      var v = this.value;
      if (state.view === "dashboard" && v) switchView("topics", { noHash: false, keepFocus: true });
      if (state.view === "topics") { state.topicKeyword = v; $("#topicSearch").value = v; renderTopics(); }
      else if (state.view === "schedule") { state.scheduleKeyword = v; $("#scheduleSearch").value = v; renderSchedule(); }
      else if (state.view === "ledger") { state.ledgerKeyword = v; $("#ledgerSearch").value = v; renderLedger(); }
    });
    document.addEventListener("keydown", function (e) {
      if ((e.ctrlKey || e.metaKey) && (e.key === "k" || e.key === "K")) {
        e.preventDefault(); $("#globalSearch").focus(); $("#globalSearch").select();
      }
    });

    /* 筛选与排序控件 */
    $("#topicSort").addEventListener("change", function () { state.topicSort = this.value; renderTopics(); });
    $("#topicClearBtn").addEventListener("click", clearTopicFilter);
    $("#scheduleTypeSelect").addEventListener("change", function () { state.scheduleType = this.value; renderSchedule(); });
    $("#scheduleSortBtn").addEventListener("click", function () { state.scheduleSortDesc = !state.scheduleSortDesc; renderSchedule(); });
    $("#scheduleExpandBtn").addEventListener("click", function () { state.scheduleExpandAll = !state.scheduleExpandAll; renderSchedule(); });
    $("#scheduleClearBtn").addEventListener("click", clearScheduleFilter);
    $("#ledgerClearBtn").addEventListener("click", clearLedgerFilter);

    /* 导出 */
    $("#topicExportBtn").addEventListener("click", function () { downloadCsv("../04_archive/内容选题库.csv", "内容选题库.csv"); });
    $("#ledgerExportBtn").addEventListener("click", function () { downloadCsv("../04_archive/内容经营台账.csv", "内容经营台账.csv"); });

    /* 刷新 */
    $("#refreshBtn").addEventListener("click", function () { loadData(false); });
    $("#settingsRefreshBtn").addEventListener("click", function () { loadData(false); });
    $("#settingsReloadBtn").addEventListener("click", function () { location.reload(); });
    $("#apiOpenBtn").addEventListener("click", function () { window.open("/api/data", "_blank"); });
    $("#openStartGuideBtn").addEventListener("click", function () {
      var dlg = $("#recordDialog");
      $("#recordDialogEyebrow").textContent = "How to Start";
      $("#recordDialogTitle").textContent = "启动方式说明";
      $("#recordDialogSub").textContent = "本地服务 · 双击快捷指令";
      $("#recordDialogBody").innerHTML =
        '<dl class="row-detail" style="grid-template-columns:7em 1fr">' +
        "<dt>macOS</dt><dd>双击案例根目录 <code>start_dashboard_macos.command</code>（首次需右键→打开，或终端执行 <code>chmod +x</code>）</dd>" +
        "<dt>Windows</dt><dd>双击案例根目录 <code>start_dashboard_windows.bat</code>（需安装 Python 3 并加入 PATH）</dd>" +
        "<dt>手动</dt><dd><code>python3 05_script/serve_dashboard.py</code>（默认端口 8765，可带端口参数）</dd>" +
        "<dt>停止</dt><dd>终端按 Ctrl+C，或直接关闭窗口</dd>" +
        "<dt>地址</dt><dd><code>http://localhost:8765/06_webapp/index.html</code></dd></dl>";
      var primaryBtn = $("#recordDialogPrimary");
      primaryBtn.textContent = "复制启动命令";
      primaryBtn.setAttribute("data-act", "");
      primaryBtn.onclick = function () { copyText("python3 05_script/serve_dashboard.py", "启动命令已复制"); };
      $("#recordDialogCopy").onclick = null;
      dlg.showModal();
    });
    $("#uiTplBtn").addEventListener("click", function () {
      window.open("../workbench-ui-template/设计说明.md", "_blank");
    });
    $("#settingsCopyBtn").addEventListener("click", function () {
      copyText($("#settingsVerifyText").textContent + "\n" + $("#settingsVerifyCode").textContent, "核验结果已复制");
    });

    /* hash 路由 */
    window.addEventListener("hashchange", function () { switchView(viewFromHash(), { noHash: true }); });
  }

  function clearTopicFilter() {
    state.topicKeyword = ""; state.topicType = ""; state.topicStatus = "";
    var el = $("#topicSearch"); if (el) el.value = "";
    renderTopics(); showToast("选题库筛选已清空");
  }
  function clearScheduleFilter() {
    state.scheduleKeyword = ""; state.scheduleStatus = ""; state.scheduleType = "";
    var el = $("#scheduleSearch"); if (el) el.value = "";
    renderSchedule(); showToast("排期筛选已清空");
  }
  function clearLedgerFilter() {
    state.ledgerKeyword = ""; state.ledgerChannel = "";
    var el = $("#ledgerSearch"); if (el) el.value = "";
    renderLedger(); showToast("台账筛选已清空");
  }

  /* ---------- 启动 ---------- */
  bindEvents();
  switchView(viewFromHash(), { noHash: true });
  loadData(true);
})();
