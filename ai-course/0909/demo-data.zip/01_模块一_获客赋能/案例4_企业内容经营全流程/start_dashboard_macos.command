#!/bin/bash
# ============================================================
#  案例4｜内容经营看板 快速启动（macOS / Linux）
#  双击本文件（或在终端执行）即可启动本地服务，
#  并自动用默认浏览器打开看板页面。
#  依赖：python3（macOS 系统自带）。
#  停止：终端按 Ctrl+C，或直接关闭终端窗口。
# ============================================================

# 切换到案例根目录（本脚本已与 05_script 位于同一目录下）
cd "$(dirname "$0")" || exit 1

# 检查 python3
if ! command -v python3 >/dev/null 2>&1; then
    echo "[错误] 未检测到 python3，请先安装 Python 3.8+。"
    read -r -p "按回车键退出..."
    exit 1
fi

echo "正在启动案例4看板服务：http://localhost:8765 ..."
python3 "05_script/serve_dashboard.py" "$@"

echo ""
echo "服务已停止。"
read -r -p "按回车键退出..."
