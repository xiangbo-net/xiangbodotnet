# 05_script｜脚本运行说明

## 脚本清单

| 脚本 | 用途 | 依赖 |
|---|---|---|
| `generate_dashboard_data.py` | 读取 `04_archive/` 的《内容选题库.csv》《内容经营台账.csv》，统计生成 `06_webapp/data.js`（看板数据） | 仅 Python 3 标准库 |
| `serve_dashboard.py` | 以案例根目录为站点根启动本地 HTTP 服务（默认端口 8765），自动打开看板页面；供看板"导出 CSV"等功能在同源下工作 | 仅 Python 3 标准库 |
| `start_dashboard_macos.command` | macOS 快捷启动：位于**案例根目录**，双击即启动服务并打开看板（也可终端执行） | python3（macOS 自带） |
| `start_dashboard_windows.bat` | Windows 快捷启动：位于**案例根目录**，双击即启动服务并打开看板（需已安装 Python 并加入 PATH） | Python 3.8+ |

## 运行方式

在**案例根目录**（`案例4_企业内容经营全流程/`）执行：

```bash
python3 05_script/generate_dashboard_data.py
```

运行成功后：

- 输出文件：`06_webapp/data.js`（被 `06_webapp/index.html` 加载）；
- 终端打印生成摘要（数据状态、核心指标、类型分布）。

## 启动看板本地服务（推荐）

**方式一（最快）**：双击对应系统的快捷指令——
- macOS：`start_dashboard_macos.command`（位于案例根目录）
- Windows：`start_dashboard_windows.bat`（位于案例根目录；文件为纯 ASCII，无编码乱码风险）

**方式二（终端）**：

```bash
python3 05_script/serve_dashboard.py          # 默认端口 8765
python3 05_script/serve_dashboard.py 9000     # 自定义端口
```

启动后自动打开 `http://localhost:8765/06_webapp/index.html`；停止按 Ctrl+C。

> 为什么需要服务而不直接双击 index.html：直接以 `file://` 打开时，看板的"导出选题库/导出台账"按钮（fetch `../04_archive/*.csv`）会被浏览器同源策略拦截；通过本服务访问则导出功能完整可用。临时看一眼数据时直接双击 index.html 也可以。

**Windows 用户注意**：首次双击 `.bat` 前确认已安装 Python 3.8+ 并勾选"Add Python to PATH"；如遇端口占用，可编辑 `.bat` 在 `python` 命令后追加端口号，或用方式二指定端口。

## 运行时机

1. **演示第四步（看板）前**：课堂完成第二/三步、台账有数据后运行，再双击打开 `06_webapp/index.html`；
2. **每日发布回写后**（可选）：更新看板数据。

## 异常行为说明

- CSV 缺失或为空表：脚本**正常退出**，生成"空数据"data.js（看板显示空状态），并在 `meta.notes` 标注"未找到/待确认"；
- 字段缺失：对应统计按空值处理，不中断运行；
- 脚本只读 `04_archive/`、只写 `06_webapp/data.js`，不修改任何其他文件。

## 数据核验口径

看板上的每个数字均由本脚本从 `04_archive/` CSV 统计得出，可现场核验；脚本不生成或虚构任何数据。
