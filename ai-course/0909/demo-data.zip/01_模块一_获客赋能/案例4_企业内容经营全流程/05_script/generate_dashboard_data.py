#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""案例4｜生成工作台本地数据快照 data.js（仅 Python 3 标准库）

用途：
  读取 04_archive 下的《内容选题库.csv》《内容经营台账.csv》，
  生成 06_webapp/data.js（window.DASHBOARD_DATA = {...}）。

  该快照仅用于「直接双击 index.html（file://）」时的离线回退展示；
  通过本地服务（05_script/serve_dashboard.py）打开时，前端优先请求
  /api/data 实时接口，本快照不参与。因此修改 CSV 后：
  - 本地服务打开：无需运行本脚本，点"刷新数据"即可；
  - file:// 直开：需重新运行本脚本刷新快照。

运行：python3 05_script/generate_dashboard_data.py
"""
import csv
import json
import os
import datetime

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TOPIC_CSV = os.path.join(ROOT, "04_archive", "内容选题库.csv")
LEDGER_CSV = os.path.join(ROOT, "04_archive", "内容经营台账.csv")
OUT = os.path.join(ROOT, "06_webapp", "data.js")

TOPIC_KEYS = {
    "选题ID": "id", "创作类型": "type", "选题": "title", "选题公式拆解": "formula",
    "目标受众": "audience", "参考素材ID": "materials", "适用渠道": "channels",
    "状态": "status", "风险提示": "risk",
}
LEDGER_KEYS = {
    "日期": "date", "星期": "weekday", "内容ID": "id", "创作类型": "type",
    "推荐选题": "topic", "主渠道": "channel", "衍生渠道": "derived", "状态": "status",
    "标题": "title", "发布链接": "link", "发布时间": "publishTime", "备注": "note",
}


def read_table(path, key_map):
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        rows = []
        for raw in csv.DictReader(f):
            row = {key: (raw.get(col) or "").strip() for col, key in key_map.items()}
            if any(row.values()):
                rows.append(row)
        return rows


def main():
    topics = read_table(TOPIC_CSV, TOPIC_KEYS)
    ledger = read_table(LEDGER_CSV, LEDGER_KEYS)
    ledger.sort(key=lambda r: r.get("date") or "")
    payload = {
        "updatedAt": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "source": "snapshot",
        "topics": topics,
        "ledger": ledger,
    }
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        f.write("/* 内容工作台本地数据快照（由 05_script/generate_dashboard_data.py 生成）\n")
        f.write("   仅用于 file:// 直开时的回退展示；本地服务打开时前端优先请求 /api/data */\n")
        f.write("window.DASHBOARD_DATA = ")
        f.write(json.dumps(payload, ensure_ascii=False, indent=2))
        f.write(";\n")
    print("[完成] 已生成 %s（选题 %d 条 ｜ 台账 %d 条）" % (OUT, len(topics), len(ledger)))


if __name__ == "__main__":
    main()
