#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""案例4｜内容工作台本地服务（仅 Python 3 标准库，无第三方依赖）

用途：
  以案例根目录为站点根，启动本地 HTTP 服务并自动打开工作台页面。

  1. 静态文件：工作台前端（06_webapp/）与数据表（04_archive/）；
  2. 动态数据接口：GET /api/data —— 每次请求实时解析 04_archive 下的
     《内容选题库.csv》《内容经营台账.csv》并返回 JSON，
     前端"刷新数据"即可拿到最新表格内容，无需重新生成任何文件；
  3. 以根目录为站点根的原因：前端需要 fetch ../04_archive/*.csv 导出源表，
     必须让 04_archive 位于同一站点下才能成功。

运行（在任意目录均可，脚本自动定位案例根目录）：
  python3 05_script/serve_dashboard.py            # 默认端口 8765
  python3 05_script/serve_dashboard.py 9000       # 自定义端口

停止：终端按 Ctrl+C。
"""
import csv
import http.server
import json
import socketserver
import webbrowser
import datetime
import os
import sys

# 案例根目录 = 本脚本所在目录的上一级（05_script/ 的父目录）
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_PORT = 8765

TOPIC_CSV = os.path.join(ROOT, "04_archive", "内容选题库.csv")
LEDGER_CSV = os.path.join(ROOT, "04_archive", "内容经营台账.csv")

# 选题库 CSV 列 → 前端字段映射
TOPIC_KEYS = {
    "选题ID": "id",
    "创作类型": "type",
    "选题": "title",
    "选题公式拆解": "formula",
    "目标受众": "audience",
    "参考素材ID": "materials",
    "适用渠道": "channels",
    "状态": "status",
    "风险提示": "risk",
}

# 台账 CSV 列 → 前端字段映射
LEDGER_KEYS = {
    "日期": "date",
    "星期": "weekday",
    "内容ID": "id",
    "创作类型": "type",
    "推荐选题": "topic",
    "主渠道": "channel",
    "衍生渠道": "derived",
    "状态": "status",
    "标题": "title",
    "发布链接": "link",
    "发布时间": "publishTime",
    "备注": "note",
}


def read_table(path, key_map):
    """按 key_map 读取一张 CSV（UTF-8 BOM 兼容），返回字典列表。"""
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        rows = []
        for raw in csv.DictReader(f):
            row = {}
            for col, key in key_map.items():
                value = (raw.get(col) or "").strip()
                row[key] = value
            if any(row.values()):
                rows.append(row)
        return rows


def build_data_payload():
    """实时读取 04_archive 两张数据表，组装前端 JSON。"""
    topics = read_table(TOPIC_CSV, TOPIC_KEYS)
    ledger = read_table(LEDGER_CSV, LEDGER_KEYS)
    ledger.sort(key=lambda r: r.get("date") or "")
    return {
        "updatedAt": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "source": "api",
        "topics": topics,
        "ledger": ledger,
    }


class DashboardHandler(http.server.SimpleHTTPRequestHandler):
    """静态文件 + /api/data 动态数据；修正中文 MIME 与编码，允许本机跨域。"""

    extensions_map = {
        **http.server.SimpleHTTPRequestHandler.extensions_map,
        ".html": "text/html; charset=utf-8",
        ".htm": "text/html; charset=utf-8",
        ".js": "application/javascript; charset=utf-8",
        ".css": "text/css; charset=utf-8",
        ".csv": "text/csv; charset=utf-8",
        ".svg": "image/svg+xml",
        ".md": "text/markdown; charset=utf-8",
        ".json": "application/json; charset=utf-8",
    }

    # ---------- 动态数据接口 ----------
    def do_GET(self):
        path = self.path.split("?", 1)[0].split("#", 1)[0]
        if path in ("/api/data", "/api/data.json"):
            self._send_json(build_data_payload())
            return
        super().do_GET()

    def _send_json(self, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        super().end_headers()

    def log_message(self, fmt, *args):
        sys.stdout.write("  [请求] %s\n" % (fmt % args))


def main():
    port = DEFAULT_PORT
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
        except ValueError:
            print("[错误] 端口参数必须是整数，例如：python3 serve_dashboard.py 9000")
            sys.exit(1)

    # 启动自检：数据表是否可读
    payload_probe = build_data_payload()
    print("[自检] 选题库 %d 条 ｜ 台账 %d 条" % (len(payload_probe["topics"]), len(payload_probe["ledger"])))

    os.chdir(ROOT)
    socketserver.TCPServer.allow_reuse_address = True
    url = "http://localhost:%d/06_webapp/index.html" % port

    try:
        httpd = socketserver.ThreadingTCPServer(("", port), DashboardHandler)
    except OSError as e:
        print("[错误] 端口 %d 启动失败：%s" % (port, e))
        print("提示：可能是端口被占用，换一个端口试试，例如 python3 serve_dashboard.py 8766")
        sys.exit(1)

    print("=" * 52)
    print("案例4｜内容工作台 本地服务已启动")
    print("  工作台地址: %s" % url)
    print("  动态数据接口: http://localhost:%d/api/data" % port)
    print("  站点根目录: %s" % ROOT)
    print("  停止方式 : 终端按 Ctrl+C（或直接关闭窗口）")
    print("=" * 52)

    # 延迟 0.5s 打开浏览器，确保服务已就绪
    import threading
    threading.Timer(0.5, lambda: webbrowser.open(url)).start()

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n[提示] 服务已停止。")


if __name__ == "__main__":
    main()
