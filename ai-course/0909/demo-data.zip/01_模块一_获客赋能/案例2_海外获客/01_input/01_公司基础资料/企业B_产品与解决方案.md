# 企业B｜产品与解决方案清单（教学模拟）

> **资料性质**：教学模拟（fictional） · **基准日期**：2026-09-07
> 与 `企业B_公司介绍_中英文.md` 口径一致；仅承载"分类 + 场景"颗粒度，不给出"具体客户 × 具体节拍 × 具体数字"。

---

## 一、解决方案概览

| 编号 | 解决方案名 | 面向场景 | 关键模块 |
|---|---|---|---|
| SOL-B-01 | 装配线节拍优化与视觉检测 | 多工位人工装配线 | 节拍分析 + 视觉定位 + 上下料 |
| SOL-B-02 | 包装线机器人上下料 | 包装线末端或装箱工位 | 机器人 + 视觉 + 输送同步 |
| SOL-B-03 | 存量 PLC 数据采集与看板 | 已运行多年的 PLC 产线 | 边缘网关 + 看板 + 报警 |

---

## 二、解决方案详述（教学版）

### SOL-B-01｜装配线节拍优化与视觉检测

- **典型问题（教学）**：装配线节拍不均、瓶颈工位依赖人工目检、来料位置偏差导致装配错位。
- **方案构成（教学）**
  - 工位节拍测量与瓶颈定位（不公开具体节拍提升数字）
  - 视觉定位与来料纠偏
  - 半自动上下料工装（兼容现有夹具）
- **交付物形态（教学）**：方案文档 + 调试记录 + 培训移交清单
- **不做的事**：不承诺具体节拍百分比、不指定具体机器型号清单、不指定具体相机品牌

### SOL-B-02｜包装线机器人上下料

- **典型问题（教学）**：包装末端人工搬运强度大、节拍受限、码垛一致性差。
- **方案构成（教学）**
  - 末端抓取与放置工装
  - 视觉识别多 SKU
  - 与上游输送节拍同步
- **交付物形态（教学）**：工装设计说明 + 程序包 + 现场调试 SOP
- **不做的事**：不给出 ROI 数字、不指定末端执行器品牌、不承诺节拍上限

### SOL-B-03｜存量 PLC 数据采集与看板

- **典型问题（教学）**：PLC 数据沉睡、无法进入 MES、班组长缺乏可视化工具。
- **方案构成（教学）**
  - 边缘网关适配主流 PLC 协议
  - 数据上云或局域网看板
  - 报警规则与交接班记录
- **交付物形态（教学）**：网关配置 + 看板页面 + 报警手册
- **不做的事**：不保证打通所有第三方系统、不指定具体 MES 厂商、不承诺数据保留年限

---

## 三、英文产品页口径（与中文同步）

| Code | Solution (Teaching) | Scenario (Teaching) |
|---|---|---|
| SOL-B-01 | Assembly line cycle-time review with vision inspection | Multi-station manual assembly |
| SOL-B-02 | Robotic pick-and-place on packaging lines | End-of-line or case packing |
| SOL-B-03 | Brownfield PLC data acquisition and dashboards | Legacy PLC lines |

### Elevator (English, teaching)

> We help Southeast Asian manufacturers retrofit assembly and packaging lines in phased steps. Solutions are designed to coexist with installed fixtures and to be handed over cleanly to your local engineering team.

---

## 四、边界与口径

- **不写** 具体型号清单 / 具体节拍数字 / 具体认证编号 / 具体客户授权
- **不写** 价格、折扣、交期、合同模板（一切项目级数据）
- **不写** 任何"已落地 X 国 Y 厂 Z 线"的虚构细节
- **保留** 一切项目级字段需由人工确认的提示

---

## 五、版本说明

| 项 | 内容 |
|---|---|
| 资料版本 | v1.0 |
| 基准日期 | 2026-09-07 |
| 上游依赖 | 企业B_公司介绍_中英文.md |
| 下游引用 | 02_prompt 第一步「理想客户画像」生成时读取 |