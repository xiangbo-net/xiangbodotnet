# 企业B｜中英文公司介绍（完整版）

> **资料性质声明**
> - 资料性质：教学模拟（fictional teaching profile）
> - 基准日期：2026-09-07
> - 资料维护：仅供本案例课堂演示使用；公司名称、产品、客户、业绩、联系人、认证、价格、交期、合同等均属教学构造
> - 教学红线：禁止作为真实商业承诺对外披露；禁止用于建立实际业务联系；禁止替换为真实企业资料流通
> - 与本目录其他资料（产品服务清单、案例与资质、品牌表达、业务边界）的口径严格一致

---

## 一、企业基础信息（中文）

| 字段 | 内容（教学模拟） |
|---|---|
| 公司全称 | 启辰自动化解决方案有限公司 |
| 英文名称 | Qichen Automation Solutions Co., Ltd. |
| 总部 | 中国 深圳 |
| 业务定位 | 工业自动化集成与设备出口商；为东南亚制造业提供分阶段改造与本地化技术支援 |
| 成立情境（教学） | 假定为聚焦工业自动化的中型系统集成商 |
| 主营产品 | 产线自动化改造方案、机器视觉检测站、机器人上下料工作站、PLC 与 MES 边缘集成网关 |
| 目标市场 | 东南亚（重点：越南、泰国、印尼，逐步覆盖马来西亚、菲律宾） |
| 目标客户类型 | 系统集成商（System Integrator）、设备经销商（Distributor / Agent）、终端制造企业（End-user Manufacturer） |
| 内容受众 | 制造企业负责人、生产负责人、技术负责人；海外为采购 / 工程对接人 |

> ⚠️ 公司名称、组织架构、营收数据、员工数、注册地等敏感字段均未填写真实信息；课堂使用请保持"虚构教学企业"定位。

---

## 二、价值主张（Value Proposition）

> **三句话版（教学版）**
>
> 1. **分阶段实施**：将整线改造拆解为可独立验收的小步快跑节点，降低一次性投资风险。
> 2. **兼容存量设备**：在保留客户既有 PLC、传感器、夹具的前提下做增量升级，减少停产与重复采购。
> 3. **可维护性优先**：方案文档、备件清单、远程诊断通道以本地工程师可接手为目标设计。

**辅助解释（仅供讲解）**

- 所有关于"节拍提升 X%""成本下降 Y%""认证齐全 Z 项""本地服务 N 城覆盖"等表述，必须保留"项目级人工确认"附注。
- 不在任何材料中虚构具体节拍数字、具体客户授权、具体认证编号、具体本地服务网点。

---

## 三、核心能力清单（Capability Map）

| 能力类别 | 具体能力（教学） | 适用场景示例（教学） |
|---|---|---|
| 产线自动化改造 | 节拍优化、瓶颈工位重构、信号链梳理 | 装配线、包装线、检测线 |
| 机器视觉 | 2D/3D 视觉定位、外观检测、读码识别 | 零部件质检、外包装合规 |
| 机器人工作站 | 上下料、码垛、焊接、打磨、抛光 | 高重复或高强度工位 |
| PLC & 边缘集成 | 西门子 / 三菱 / 欧姆龙 PLC 程序，MES 边缘网关 | 旧线数据采集与看板 |
| 技术支援 | 远程诊断、现场调试、培训移交 | 海外项目落地 |

> 教学提示：以上能力描述均保持"分类 + 场景"颗粒度，不给出"特定客户 × 特定型号 × 特定节拍"的虚构细节。

---

## 四、典型合作模式（教学说明）

| 合作模式 | 适用对象 | 备注 |
|---|---|---|
| 联合交付 | 系统集成商 | 启辰出方案 + 集成商出实施 |
| 渠道经销 | 设备经销商 | 由经销商负责本地销售与服务 |
| 直签终端 | 大型制造企业 | 项目级评估；不走标准化报价 |

> ⚠️ 是否签约、走何种合作模式由项目级人工评估决定；本案例不擅自指定。

---

## 五、教学边界与口径

- **不虚构**：认证编号、客户授权、节拍提升、成本下降、本地服务网点、案例公司真实名称、合同金额。
- **不替代**：本资料不替代尽调、不替代法律意见、不替代财务评估。
- **不外发**：仅在课堂范围内使用；学员与讲师不得将本资料用于真实商务触达。
- **不采集**：禁止把学员真实个人信息或真实客户资料写入本案例任何输出文件。

---

## 六、English Profile (Teaching Only)

**Qichen Automation Solutions** is a fictional teaching company used in classroom demonstrations of overseas customer development. It is presented as a mid-sized industrial automation integrator exporting phased retrofit, machine vision and integration solutions to Southeast Asian partners. All commercial terms, certifications, delivery commitments and local service capabilities must be confirmed project by project by a human.

### One-paragraph elevator pitch (teaching)

> We help Southeast Asian manufacturers upgrade assembly and packaging lines in phased, reversible steps. Our focus is compatibility with installed PLCs and fixtures, maintainability by local engineers, and clear handover documentation. We do not claim specific cycle-time gains, cost savings, certifications, or local coverage without project-level human approval.

### Capability summary (teaching)

| Area | What we cover (teaching) | What we do NOT claim |
|---|---|---|
| Line retrofit | Cycle-time bottleneck review, signal-chain clean-up | Specific % improvement numbers |
| Machine vision | 2D / 3D positioning, inspection, code reading | Specific defect-rate reduction |
| Robotics | Pick-and-place, palletizing, welding, polishing | Specific ROI payback period |
| PLC & edge | Siemens / Mitsubishi / Omron PLC, MES edge gateway | Specific certification IDs |
| Support | Remote diagnostics, on-site commissioning, training | Specific city-by-line SLA |

### Disclaimer

> This is teaching material. Company name, projects, certifications, performance figures, contact persons and commercial terms are fictional. Do not use this profile for real outreach, lead nurturing, contract drafting or public disclosure.

---

## 七、版本说明

| 项 | 内容 |
|---|---|
| 资料版本 | v1.0（完整版） |
| 基准日期 | 2026-09-07 |
| 上游依赖 | 无（独立可读） |
| 下游引用 | 被 02_prompt/00_分步提示词操作手册.md 第一步读取 |