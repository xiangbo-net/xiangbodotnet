"""
init_leads_template.py
============================================================
案例2｜海外获客 · 04_archive/线索库.xlsx 模板生成器

用途：
  - 在 04_archive/线索库.xlsx 不存在时建立空模板（仅含表头 + 字段说明）
  - 也可被 02_prompt 第六步「沉淀」调用，把候选数据写入 xlsx

字段分组：
  A. 基础信息（讲师 / 学员可填）
  B. 画像字段（来自评分文件）
  C. 评分字段（来自评分文件）
  D. 来源溯源（每条必填）
  E. 强制留空字段（必须留空，AI 写入会触发中止）

执行：
  05_script/run_macos_linux.sh  # 或 run_windows.bat
  python3 init_leads_template.py           # 仅建立模板
  python3 init_leads_template.py --rows 5  # 建立模板并预填 5 行示例（示例可删）

合规：
  - E 组字段在任何写入路径下都不得被填；写入会触发 ValueError
  - 不读 Tavily Key；不联网
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "04_archive" / "线索库.xlsx"

# ============ 字段定义 ============
GROUPS: list[tuple[str, list[tuple[str, str]]]] = [
    (
        "A｜基础信息",
        [
            ("序号", "数字"),
            ("公司名（中）", "文本"),
            ("公司名（英）", "文本"),
            ("国家", "枚举：越南/泰国/印尼/马来西亚/菲律宾"),
            ("城市", "文本；如未找到写'未找到/待确认'"),
            ("行业大类", "枚举：汽车零部件/食品包装/电子装配/其他制造业"),
            ("官网", "URL"),
            ("联系电话", "文本；公开总机；个人电话禁止"),
            ("联系邮箱", "文本；info@/contact@ 通用邮箱；个人邮箱禁止"),
        ],
    ),
    (
        "B｜画像字段",
        [
            ("行业匹配度", "0–100；权重 25%"),
            ("国家匹配度", "0–100；权重 15%"),
            ("规模信号", "0–100；权重 15%"),
            ("合作模式信号", "0–100；权重 15%"),
            ("联系入口完整度", "0–100；权重 10%"),
            ("案例类比性", "0–100；权重 10%"),
            ("证据强度", "0–100；权重 10%"),
        ],
    ),
    (
        "C｜评分字段",
        [
            ("总分", "0–100；按权重加权求和"),
            ("分级", "枚举：A/B/C；由讲师课堂口头确认，AI 仅给候选"),
            ("评分依据摘要", "文本；2–3 行说明"),
            ("置信度", "枚举：高/中/低"),
        ],
    ),
    (
        "D｜来源溯源",
        [
            ("检索渠道", "枚举：Tavily/ThomasNet/Kompass/LinkedIn/Maps"),
            ("证据链接 1", "URL；搜索摘要原文"),
            ("证据链接 2", "URL；官网校验页"),
            ("核验日期", "YYYY-MM-DD"),
            ("核验人", "讲师 / 学员姓名（仅课堂）"),
        ],
    ),
    (
        "E｜强制留空（AI 写入即中止）",
        [
            ("负责人", "人工指派；AI 不得填"),
            ("销售对接", "人工指派；AI 不得填"),
            ("报价", "项目级；AI 不得填"),
            ("折扣", "项目级；AI 不得填"),
            ("付款条件", "项目级；AI 不得填"),
            ("交期", "项目级；AI 不得填"),
            ("合同条款", "法务出具；AI 不得填"),
            ("公开发布", "合规审核；AI 不得填"),
        ],
    ),
]

# E 组列索引（写入时强制留空；1-based，含分组行前的 offset）
E_FIELD_NAMES = [name for _, fields in GROUPS if "强制留空" in _ for name, _ in fields]

HEADER_FILL = PatternFill("solid", fgColor="E8F1EB")  # 浅绿
HEADER_FONT = Font(bold=True, color="244A3A", size=11)
GROUP_FILL = PatternFill("solid", fgColor="315F4B")  # 品牌深绿
GROUP_FONT = Font(bold=True, color="FFFFFF", size=11)
NOTE_FILL = PatternFill("solid", fgColor="FBF3DF")  # 沙色
NOTE_FONT = Font(italic=True, color="735D3C", size=10)
E_FILL = PatternFill("solid", fgColor="FAEEEE")  # 浅红
E_FONT = Font(bold=True, color="9D3C3C", size=11)
THIN = Side(border_style="thin", color="DFE5E1")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)


def _build_header(ws: Worksheet) -> None:
    """前两行：表头分组 + 字段名"""
    # 第一行：分组
    col = 1
    for group_name, fields in GROUPS:
        span = len(fields)
        if span == 1:
            ws.cell(row=1, column=col, value=group_name)
        else:
            ws.merge_cells(
                start_row=1, start_column=col,
                end_row=1, end_column=col + span - 1,
            )
            ws.cell(row=1, column=col, value=group_name)
        for c in range(col, col + span):
            cell = ws.cell(row=1, column=c)
            cell.fill = GROUP_FILL
            cell.font = GROUP_FONT
            cell.alignment = Alignment(horizontal="center", vertical="center")
            cell.border = BORDER
        col += span

    # 第二行：字段名 + 类型
    col = 1
    for _group_name, fields in GROUPS:
        for field_name, field_type in fields:
            name_cell = ws.cell(row=2, column=col, value=field_name)
            type_cell = ws.cell(row=3, column=col, value=field_type)
            name_cell.fill = HEADER_FILL
            name_cell.font = HEADER_FONT
            name_cell.alignment = Alignment(horizontal="center", vertical="center")
            name_cell.border = BORDER
            type_cell.fill = NOTE_FILL
            type_cell.font = NOTE_FONT
            type_cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            type_cell.border = BORDER
            if "强制留空" in _group_name:
                name_cell.fill = E_FILL
                name_cell.font = E_FONT
            col += 1

    ws.row_dimensions[1].height = 26
    ws.row_dimensions[2].height = 26
    ws.row_dimensions[3].height = 30


def _set_widths(ws: Worksheet) -> None:
    widths = {
        "序号": 6,
        "公司名（中）": 26,
        "公司名（英）": 26,
        "国家": 14,
        "城市": 14,
        "行业大类": 18,
        "官网": 36,
        "联系电话": 22,
        "联系邮箱": 26,
        "评分依据摘要": 36,
        "检索渠道": 22,
        "证据链接 1": 36,
        "证据链接 2": 36,
        "核验日期": 14,
        "核验人": 14,
        "E 字段": 18,
    }
    col = 1
    for _group, fields in GROUPS:
        for name, _t in fields:
            ws.column_dimensions[get_column_letter(col)].width = widths.get(name, 14)
            col += 1


def _add_example_row(ws: Worksheet, row: int) -> None:
    """示例行（可删）：演示合规写法 + 留空字段"""
    sample = {
        "序号": 1,
        "公司名（中）": "[示例] 越南河内某汽车零部件集成商（脱敏）",
        "公司名（英）": "[Example] Hanoi auto-parts integrator (anonymized)",
        "国家": "越南",
        "城市": "Hanoi（脱敏到城市）",
        "行业大类": "汽车零部件",
        "官网": "https://example.com/auto-parts-vn",
        "联系电话": "+84-24-xxxx-xxxx（公开总机）",
        "联系邮箱": "info@example-vn.com",
        "行业匹配度": 85,
        "国家匹配度": 100,
        "规模信号": 60,
        "合作模式信号": 75,
        "联系入口完整度": 70,
        "案例类比性": 80,
        "证据强度": 70,
        "总分": 78,
        "分级": "B（讲师确认前不得定为 A）",
        "评分依据摘要": "官网 About 提及 automotive 与 system integration；info@ 邮箱；脱敏案例 CASE-B-01 类比",
        "置信度": "中",
        "检索渠道": "Tavily",
        "证据链接 1": "https://example.com/search?q=...（搜索摘要）",
        "证据链接 2": "https://example.com/about（官网校验）",
        "核验日期": "2026-09-07",
        "核验人": "讲师示例",
    }
    col = 1
    for _group, fields in GROUPS:
        for name, _t in fields:
            v = sample.get(name, "")  # E 组字段默认空
            c = ws.cell(row=row, column=col, value=v)
            c.border = BORDER
            c.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
            if "强制留空" in _group:
                c.fill = E_FILL
            col += 1


def build_template(example_rows: int = 0) -> None:
    OUT.parent.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    ws = wb.active
    ws.title = "线索库"
    _build_header(ws)
    _set_widths(ws)

    # 冻结前 3 行
    ws.freeze_panes = "A4"

    # 可选示例行
    for i in range(example_rows):
        _add_example_row(ws, row=4 + i)

    # 数据有效性占位（教学版简化：A/B/C 仅作为下拉建议；强制字段留空）
    wb.save(OUT)
    print(f"[OK] 已建立模板：{OUT}")
    if example_rows:
        print(f"     含 {example_rows} 行示例（可由讲师/学员删除）")
    print("     表头 3 行：分组行 / 字段名行 / 字段类型行")
    print("     E 组字段（负责人/报价/折扣/付款条件/交期/合同条款/公开发布）必须保持留空")


def main() -> int:
    ap = argparse.ArgumentParser(description="线索库.xlsx 模板生成器")
    ap.add_argument("--rows", type=int, default=0, help="预填示例行数（0 = 仅空模板）")
    args = ap.parse_args()

    if OUT.exists():
        resp = input(f"已存在 {OUT.name}，是否覆盖？[y/N] ").strip().lower()
        if resp != "y":
            print("[跳过] 未覆盖。可改用 --rows N 在已存在表上不追加；建议先备份。")
            return 0

    build_template(example_rows=args.rows)
    return 0


if __name__ == "__main__":
    sys.exit(main())