# 05_script｜脚本目录说明

> **基准日期**：2026-09-07 · **案例**：案例2｜海外获客
> **本目录作用**：放本案例所需的本地脚本（环境自检、xlsx 模板生成）。联网检索由「海外获客专家」完成，不在本目录。

---

## 一、文件清单

| 文件 | 用途 | 是否依赖第三方 |
|---|---|---|
| `check_env.py` | 课前环境自检（Key 存在性 + 联网探测 + 专家提示） | 仅 Python 3 标准库 |
| `init_leads_template.py` | 在 04_archive/线索库.xlsx 不存在时建立空模板（含表头 + 字段类型说明） | openpyxl |
| `run_macos_linux.sh` | macOS / Linux 启动脚本（自动调用 check_env.py） | — |
| `run_windows.bat` | Windows 启动脚本 | — |
| `requirements.txt` | 第三方依赖清单 | — |
| `README.md` | 本文件 | — |

> 历史脚本 `run_case.py` 已被新版 `check_env.py` 取代，原文件移入 `待删除/` 目录。

---

## 二、环境自检 check_env.py

### 用途

讲师课前 5 分钟运行，确认三项：

1. **Tavily API Key 是否已配置到环境变量 `TAVILY_API_KEY`**
2. **是否能访问公网**（HEAD 探测 tavily.com / example.com / baidu.com）
3. **是否需要安装「海外获客专家」**（脚本不读取专家状态，仅给提示）

### 执行

```bash
# macOS / Linux
./run_macos_linux.sh
# 或
python3 check_env.py

# Windows
run_windows.bat
# 或
python check_env.py
```

### 输出

```
03_output/00_课前自检结果_<YYYY-MM-DD>.md    # 人读
03_output/00_课前自检结果_<YYYY-MM-DD>.json  # 机读
```

### 合规边界

- **不读取 Tavily Key 值**；仅判断"是否非空"并在控制台打印首末 2 字符 + 长度
- **不写入 Tavily Key 到任何文件**
- **不联网访问受保护页面**；仅 HEAD 公开域

### 通过标准

- [ ] Tavily Key 显示 ✓
- [ ] 联网探测至少 2/3 通过
- [ ] 讲师在对话中确认「海外获客专家」可被路由调用

不通过时按 `00_课前自检结果_*.md` 的"不通过时的处理"小节逐项解决。

---

## 三、xlsx 模板生成 init_leads_template.py

### 用途

按 `04_archive/README.md` 定义的 33 列字段（含 8 列强制留空字段）建立空模板。

### 执行

```bash
# 第一次使用 / 模板丢失时
python3 init_leads_template.py

# 含 5 行示例（讲师备课演示，可删）
python3 init_leads_template.py --rows 5
```

### 输出

- `04_archive/线索库.xlsx`：33 列字段 + 3 行表头（分组 / 字段名 / 字段类型）+ 可选示例行
- 已存在 xlsx 时脚本会询问"是否覆盖"；不覆盖则跳过

### 字段约束

- E 组（负责人 / 销售对接 / 报价 / 折扣 / 付款条件 / 交期 / 合同条款 / 公开发布）必须保持空值
- 任何写入路径违反此约束都会被中止并提示

---

## 四、跨平台注意事项

| 项 | macOS / Linux | Windows |
|---|---|---|
| Python | 系统 Python 3 ≥ 3.9；推荐 3.13 | 系统 Python ≥ 3.9 |
| 依赖安装 | `pip install -r requirements.txt` | `pip install -r requirements.txt` |
| 启动脚本 | `./run_macos_linux.sh`（自动用 `python3`） | 双击 `run_windows.bat` |
| 编码 | UTF-8 默认 | 终端需 UTF-8，否则中文乱码 |

> 讲师在课堂 Windows 机器上跑前，请确认 `python` 在 PATH 中且版本 ≥ 3.9。

---

## 五、合规与边界

- 任何脚本都不得读取 / 打印 / 写入 Tavily Key 的完整值
- 任何脚本都不得抓取登录后内容 / 个人社交账号
- 任何脚本都不发起真实商务触达
- 课堂产物（`03_output/00_课前自检结果_*.md`）默认不外发

---

## 六、版本说明

| 项 | 内容 |
|---|---|
| 脚本目录版本 | v1.0 |
| 基准日期 | 2026-09-07 |
| 上游依赖 | 无 |
| 下游引用 | 04_archive/线索库.xlsx、03_output 自检产物 |
| 维护人 | 案例包维护者（仅讲师） |