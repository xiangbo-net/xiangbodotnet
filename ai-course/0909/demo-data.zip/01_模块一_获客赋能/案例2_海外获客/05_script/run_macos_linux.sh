#!/usr/bin/env bash
# 案例2｜海外获客 · macOS / Linux 启动脚本
# 用途：运行课前环境自检（不读 Tavily Key 值）
set -e
cd "$(dirname "$0")"
PY=python3
if [ -x "/Users/xiangbo/.workbuddy/binaries/python/envs/default/bin/python3" ]; then
  PY="/Users/xiangbo/.workbuddy/binaries/python/envs/default/bin/python3"
fi
echo "[run] check_env.py"
$PY check_env.py