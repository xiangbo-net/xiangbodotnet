"""
check_env.py
============================================================
案例2｜海外获客 · 课前环境自检

用途：
  讲师课前 5 分钟运行，确认以下三项：
    1. Tavily API Key 是否已配置到系统环境变量（TAVILY_API_KEY）
    2. 是否能访问公网（HEAD 请求 tavily.com / 百度 / example.com）
    3. 是否能调用「海外获客专家」（脚本无法判断专家是否已装，仅给提示）

输出：
  - 03_output/00_课前自检结果_<YYYY-MM-DD>.md（人读）
  - 03_output/00_课前自检结果_<YYYY-MM-DD>.json（机读）
  - 控制台简洁摘要

合规：
  - 不读取 Tavily Key 的值；只检查"是否非空"
  - 不联网访问受保护页面；仅 HEAD 公开域名
  - 不写 Tavily Key 到任何文件
"""

from __future__ import annotations

import json
import os
import socket
import sys
import urllib.request
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "03_output"

TAVILY_KEY_ENV = "TAVILY_API_KEY"
PROBES = [
    ("tavily.com", "https://tavily.com/", "Tavily 官网"),
    ("example.com", "https://example.com/", "通用测试域"),
    ("baidu.com", "https://www.baidu.com/", "百度（中国大陆测试）"),
]
SOCKET_TIMEOUT = 4  # 秒
USER_AGENT = "Case2-EnvCheck/1.0 (teaching use only)"


def _check_key() -> tuple[str, str]:
    """检查 Tavily Key 是否存在；只判断长度，不打印值"""
    v = os.environ.get(TAVILY_KEY_ENV, "")
    if not v:
        return ("✗", f"环境变量 {TAVILY_KEY_ENV} 未设置")
    if not v.strip():
        return ("✗", f"环境变量 {TAVILY_KEY_ENV} 为空字符串")
    # 仅显示长度与首末 2 字符，绝不打印完整 Key
    masked = f"{v[:2]}…{v[-2:]}(len={len(v)})"
    return ("✓", f"Key 已配置（{masked}）")


def _check_network() -> list[dict]:
    """对多个公网域做 HEAD 探测"""
    results = []
    for host, url, label in PROBES:
        entry = {"host": host, "label": label, "ok": False, "status": None, "error": None}
        try:
            req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": USER_AGENT})
            with urllib.request.urlopen(req, timeout=SOCKET_TIMEOUT) as resp:
                entry["ok"] = True
                entry["status"] = resp.status
        except (urllib.error.URLError, socket.timeout, OSError) as e:
            entry["error"] = type(e).__name__ + ": " + str(e)[:80]
        results.append(entry)
    return results


def _check_expert_hint() -> tuple[str, str]:
    """脚本无法直接判断专家是否已装，仅给提示"""
    return (
        "ℹ",
        "请讲师在对话中输入「调用海外获客专家」验证；脚本不读取专家状态",
    )


def _summarize(key_st, net_results, expert_hint) -> dict:
    net_pass = sum(1 for r in net_results if r["ok"])
    return {
        "case": "案例2｜海外获客",
        "date": str(date.today()),
        "tavily_key": {"status": key_st[0], "note": key_st[1]},
        "network": {"passed": net_pass, "total": len(net_results), "items": net_results},
        "expert": {"status": expert_hint[0], "note": expert_hint[1]},
        "overall": "pass" if key_st[0] == "✓" and net_pass >= 2 else "fail",
    }


def _write_outputs(summary: dict) -> tuple[Path, Path]:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    today = summary["date"]
    md_path = OUT_DIR / f"00_课前自检结果_{today}.md"
    json_path = OUT_DIR / f"00_课前自检结果_{today}.json"

    # JSON
    json_path.write_text(
        json.dumps(summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    # Markdown（人读）
    lines = [
        f"# 课前环境自检结果 · {today}",
        "",
        f"> 案例：案例2｜海外获客 · 资料性质：教学模拟",
        "",
        "## 总览",
        "",
        f"- **结论**：{'✓ 通过' if summary['overall'] == 'pass' else '✗ 不通过'}",
        f"- Tavily Key：{summary['tavily_key']['status']} {summary['tavily_key']['note']}",
        f"- 联网探测：{summary['network']['passed']} / {summary['network']['total']} 通过",
        f"- 专家提示：{summary['expert']['status']} {summary['expert']['note']}",
        "",
        "## 联网探测明细",
        "",
        "| 域 | 用途 | 状态 | HTTP | 备注 |",
        "|---|---|---|---|---|",
    ]
    for item in summary["network"]["items"]:
        ok = "✓" if item["ok"] else "✗"
        status = item.get("status") or "-"
        err = item.get("error") or "-"
        lines.append(
            f"| `{item['host']}` | {item['label']} | {ok} | {status} | {err} |"
        )

    lines += [
        "",
        "## 通过标准",
        "",
        "- [ ] Tavily Key 已配置（✓）",
        "- [ ] 联网探测至少 2/3 通过（✓/✓/✗ 可开课；✓/✗/✗ 需换网络）",
        "- [ ] 讲师在对话中确认「海外获客专家」可被路由调用",
        "",
        "## 不通过时的处理",
        "",
        "1. Tavily Key ✗ → 课前到 https://www.tavily.com 注册并把 Key 写入环境变量；**不要**把 Key 写入任何案例文件",
        "2. 联网 ✗ → 切换到手机热点；或检查代理；再不行换教室网络",
        "3. 专家 ✗ → 在 WorkBuddy「专家中心」安装「海外精准获客专家」",
        "",
        "## 合规",
        "",
        "- 本自检文件不含 Tavily Key 完整值",
        "- 本自检文件不含学员 / 真实客户隐私",
        "- 课堂结束后默认归档到 03_output，不外发",
    ]
    md_path.write_text("\n".join(lines), encoding="utf-8")
    return md_path, json_path


def main() -> int:
    print("── 案例2 课前环境自检 ──")
    key_st = _check_key()
    net_results = _check_network()
    expert_hint = _check_expert_hint()
    summary = _summarize(key_st, net_results, expert_hint)

    print(f"[Tavily Key] {key_st[0]}  {key_st[1]}")
    for r in net_results:
        mark = "✓" if r["ok"] else "✗"
        print(f"[{r['host']:<14}] {mark}  HTTP={r.get('status') or '-'}  {r.get('error') or ''}")
    print(f"[专家]         {expert_hint[0]}  {expert_hint[1]}")

    md_path, json_path = _write_outputs(summary)
    print(f"\n已写入：{md_path}")
    print(f"已写入：{json_path}")

    return 0 if summary["overall"] == "pass" else 2


if __name__ == "__main__":
    sys.exit(main())