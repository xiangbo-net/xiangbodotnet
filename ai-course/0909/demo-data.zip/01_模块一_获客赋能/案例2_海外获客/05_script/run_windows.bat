@echo off
REM 案例2｜海外获客 · Windows 启动脚本
REM 用途：运行课前环境自检（不读 Tavily Key 值）
cd /d %~dp0
python check_env.py
pause